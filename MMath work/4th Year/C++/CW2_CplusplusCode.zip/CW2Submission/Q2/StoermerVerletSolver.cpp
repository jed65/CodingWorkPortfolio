#include <iostream>
#include <cassert>
#include <string>
#include <cmath>
#include "StoermerVerletSolver.hpp"

//Much of this source file has been copy/pasted/edited from Forward Euler source
//Specialised constructor
StoermerVerletSolver::
    StoermerVerletSolver(ODEInterface* pODESystem, const double initialState,
                        const double initialVelocity, const double initialTime,
                        const double finalTime, const double stepSize,
                        const std::string outputFileName,
                        const int saveGap, const int printGap)
{
    //First set the values of elements inherited from base class
    assert((initialTime>=0) && (finalTime>=0)); //times are non-negative
    assert(finalTime>initialTime); //final time should be bigger than initial
    assert(stepSize>0); //step size should also be positive
    mInitialTime=initialTime; //allocate values to the private members
    mFinalTime=finalTime;
    mStepSize=stepSize;
    mpODESystem=pODESystem;

    //Allocate values to the other private variables
    mInitialState=initialState;
    mInitialVelocity=initialVelocity;
    mOutputFileName=outputFileName;
    mSaveGap=saveGap;
    mPrintGap=printGap;
}

//Biggest changes are for these functions, as the method is different
//Override inherited function that solves, print and save to file
void StoermerVerletSolver::Solve()
{
    //Initialise the variables
    double t=mInitialTime;
    double x=mInitialState;
    double v=mInitialVelocity;
    double h=mStepSize; //This is to improve readability
    double fn; //So that we can compute the right hand side at time n
    double fnplus; //So that we can compute the right hand side at time n+1
    PrintHeader("Stoermer-Verlet method"); //Print header (inherited method)
    PrintElements(t,x,v,true); //Print column names then first row
    SaveElements(t,x,v,mOutputFileName); //Save initial values to file
    //Now implement the method
    int counter=1;
    while (t<=mFinalTime)
    {
        mpODESystem->ComputeF(t,x,fn); //Update the value of fn
        t=t+h; //Go to next time point
        x=x+h*v+0.5*pow(h,2.0)*fn; //Update value of x using formula
        mpODESystem->ComputeF(t,x,fnplus); //Update value of fnplus
        v=v+0.5*h*(fn+fnplus); //Update value of v using fn/fnplus
        if (counter%mPrintGap==0) //if counter divisible by PrintGap, then print
        {
            PrintElements(t,x,v); //print these elements to the screen
        }
        if (counter%mSaveGap==0) //if counter divisible by SaveGap, then save
        {
            SaveElements(t,x,v,mOutputFileName); //saves these elements to file
        }
        counter++;
    }
    std::cout << "-------------------------------------------------------------"
            << "-------------------------------"
    << std::endl; //Fancy footer
}

//Method to find the error when analytic solution defined
void StoermerVerletSolver::FindError(const int noOfElements,double* pError)
{
    //Copy and paste a lot of this from the Solve() function
    //Initialise the variables
    double t=mInitialTime;
    double x=mInitialState;
    double v=mInitialVelocity;
    double h=mStepSize; //This is to improve readability
    double fn; //So that we can compute the right hand side at time n
    double fnplus; //So that we can compute right hand side at time n+1
    double analytic_x; //given solution for x
    double analytic_v; //solution for v
    mpODESystem->ComputeAnalyticSolution(t,analytic_x); //Initialise x solution
    mpODESystem->ComputeAnalyticVelocity(t,analytic_v); //Initialise v solution
    //noOfElements calculated as (finalTime-initialTime)/stepSize+1
    for (int i=0; i<noOfElements;i++) //has same number of steps as Solve()
    {
        //Assign value to pError, 2-norm at each time t
        pError[i]=sqrt(pow(x-analytic_x,2.0)+pow(v-analytic_v,2.0));
        //Use Stoermer-Verlet method to update values of t,x,v
        mpODESystem->ComputeF(t,x,fn); //Update the value of f
        t=t+h; //Go to next time point
        x=x+h*v+0.5*pow(h,2.0)*fn; //Update value of x using formula
        mpODESystem->ComputeF(t,x,fnplus); //Update value of fnplus
        v=v+0.5*h*(fn+fnplus); //Update value of v using fn/fnplus
        mpODESystem->ComputeAnalyticSolution(t,analytic_x); //update x solution
        mpODESystem->ComputeAnalyticVelocity(t,analytic_v); //update v solution
    }
}
