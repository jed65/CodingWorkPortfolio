#ifndef SYMPLECTICEULERSOLVERHEADERDEF
#define SYMPLECTICEULERSOLVERHEADERDEF

#include "AbstractODESolver.hpp" //derived from this abstract class
//This header file formed by copy/paste/edit of Forward Euler header
class SymplecticEulerSolver: public AbstractODESolver
{
    public:
     //Public constructor, change outputFileName to avoid confusion
     SymplecticEulerSolver(ODEInterface* pODESystem, const double initialState,
                        const double initialVelocity, const double initialTime,
                        const double finalTime, const double stepSize,
                        const std::string outputFileName="outputSE.dat",
                        const int saveGap=1, const int printGap=1);
    //Override solve
    void Solve();
    //Method to find error
    void FindError(const int noOfElements, double* pError);
 private:
    double mInitialState; //add some elements we need that aren't inherited
    double mInitialVelocity;
    std::string mOutputFileName;
    int mSaveGap;
    int mPrintGap;
};

#endif
