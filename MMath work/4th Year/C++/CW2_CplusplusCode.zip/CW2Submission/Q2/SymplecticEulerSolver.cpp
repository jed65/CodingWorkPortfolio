#include <iostream>
#include <cassert>
#include <string>
#include <cmath>
#include "SymplecticEulerSolver.hpp"

//Much of this source file has been copy/pasted/edited from Forward Euler source
//Specialised constructor
SymplecticEulerSolver::
    SymplecticEulerSolver(ODEInterface* pODESystem, const double initialState,
                        const double initialVelocity, const double initialTime,
                        const double finalTime, const double stepSize,
                        const std::string outputFileName,
                        const int saveGap, const int printGap)
{
    //First set the values of elements inherited from base class
    assert((initialTime>=0) && (finalTime>=0)); //times are non-negative
    assert(finalTime>initialTime); //final time should be bigger than initial
    assert(stepSize>0); //step size should also be positive
    mInitialTime=initialTime; //allocate values to the private members
    mFinalTime=finalTime;
    mStepSize=stepSize;
    mpODESystem=pODESystem;

    //Allocate values to the other private variables
    mInitialState=initialState;
    mInitialVelocity=initialVelocity;
    mOutputFileName=outputFileName;
    mSaveGap=saveGap;
    mPrintGap=printGap;
}

//Biggest changes are for these functions, as the method is different
//Override inherited function that solves, print and save to file
void SymplecticEulerSolver::Solve()
{
    //Initialise the variables
    double t=mInitialTime;
    double x=mInitialState;
    double v=mInitialVelocity;
    double h=mStepSize; //This is to improve readability
    double f; //So that we can compute the right hand side
    PrintHeader("Symplectic Euler method"); //Print header (inherited method)
    PrintElements(t,x,v,true); //Print column names then first row
    SaveElements(t,x,v,mOutputFileName); //Save initial values to file
    //Now implement the method
    int counter=1;
    while (t<=mFinalTime)
    {
        mpODESystem->ComputeF(t,x,f); //Update the value of f
        t=t+h; //go to next time point
        v=v+h*f; //update value of v first (this is the major difference)
        x=x+h*v; //update value of x using updated value of v
        if (counter%mPrintGap==0) //if counter divisible by PrintGap, then print
        {
            PrintElements(t,x,v); //print these elements to the screen
        }
        if (counter%mSaveGap==0) //if counter divisible by SaveGap, then save
        {
            SaveElements(t,x,v,mOutputFileName); //saves these elements to file
        }
        counter++;
    }
    std::cout << "-------------------------------------------------------------"
            << "-------------------------------"
    << std::endl; //Fancy footer
}

//Method to find the error when analytic solution defined
void SymplecticEulerSolver::FindError(const int noOfElements,double* pError)
{
    //Copy and paste a lot of this from the Solve() function
    //Initialise the variables
    double t=mInitialTime;
    double x=mInitialState;
    double v=mInitialVelocity;
    double h=mStepSize; //This is to improve readability
    double f; //So that we can compute the right hand side
    double analytic_x; //given solution for x
    double analytic_v; //solution for v
    mpODESystem->ComputeAnalyticSolution(t,analytic_x); //Initialise x solution
    mpODESystem->ComputeAnalyticVelocity(t,analytic_v); //Initialise v solution
    //noOfElements calculated as (finalTime-initialTime)/stepSize+1
    for (int i=0; i<noOfElements;i++) //has same number of steps as Solve()
    {
        //Assign value to pError, 2-norm at each time t
        pError[i]=sqrt(pow(x-analytic_x,2.0)+pow(v-analytic_v,2.0));
        //Use Symplectic Euler method to update values of t,x,v
        mpODESystem->ComputeF(t,x,f); //Update the value of f
        t=t+h; //go to next time point
        v=v+h*f; //update value of v (do this FIRST, symplectic)
        x=x+h*v; //update value of x
        mpODESystem->ComputeAnalyticSolution(t,analytic_x); //update x solution
        mpODESystem->ComputeAnalyticVelocity(t,analytic_v); //update v solution
    }
}
