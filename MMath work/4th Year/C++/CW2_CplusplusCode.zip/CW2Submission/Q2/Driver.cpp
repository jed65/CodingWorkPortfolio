#include <iostream>
#include <fstream>
#include <cassert>
#include "OscillatorODE.hpp"
#include "SymplecticEulerSolver.hpp"
#include "StoermerVerletSolver.hpp"

int main(int argc,char* argv[])
{
    //Same process as before for part i
    //First define and allocate storage to ODESystem
    ODEInterface* pODESystem=new OscillatorODE(1.5); //a set equal to 1.5
    //Define/allocate storage for symplectic Euler system
    SymplecticEulerSolver* p_symplectic_euler=
    new SymplecticEulerSolver(pODESystem,0.0,1.5,0.0,30.0,0.01,"outputSE.dat",
                              1,100);
    p_symplectic_euler->Solve(); //call to print solution/save to file
    //Repeat for the Stoermer-Verlet method
    StoermerVerletSolver* p_stoermer_verlet=
    new StoermerVerletSolver(pODESystem,0.0,1.5,0.0,30.0,0.01,"outputSV.dat",
                             1,100);
    p_stoermer_verlet->Solve(); //call to print solution/save to file
    //Note that again, I deliberately chose mPrintGap=100 so output suitable
    //size for the latex file, gives values at t=0,1,...,30 from h=0.01.

    //Next vary values of h and look at error
    double h=0.2; //initial value of h which we will continuously half
    int almostNoOfElements=5; //this is 1/h
    std::ofstream errorsSE_file; //define output stream for symplectic errors
    errorsSE_file.setf(std::ios::scientific,std::ios::floatfield);
    errorsSE_file.precision(6); //these lines ensure high precision
    errorsSE_file.open("errorsSEQ2c.dat"); //open file
    assert(errorsSE_file.is_open()); //check that file is open
    std::ofstream errorsSV_file; //repeat for stoermer-verlet errors
    errorsSV_file.setf(std::ios::scientific,std::ios::floatfield);
    errorsSV_file.precision(6); //these lines ensure high precision
    errorsSV_file.open("errorsSVQ2c.dat"); //open file
    assert(errorsSV_file.is_open()); //check that file is open

    //Now find E(h) for each h and write them to the files
    for (int i=1;i<=10;i++)
    {
        //Declare new symplectic system
        SymplecticEulerSolver* p_symplectic_euler_various_h=
        new SymplecticEulerSolver(pODESystem,0.0,1.5,0.0,1.0,h);
        //Declare new stoermer-verlet system
        StoermerVerletSolver* p_stoermer_verlet_various_h=
        new StoermerVerletSolver(pODESystem,0.0,1.5,0.0,1.0,h);
        double* pErrorSE; //Declare error vector for symplectic
        double* pErrorSV; //Declare error vector for stoermer-verlet
        pErrorSE=new double[almostNoOfElements+1]; //allocate storage
        pErrorSV=new double[almostNoOfElements+1];
        for (int k=0; k<=almostNoOfElements;k++)
        {
            pErrorSE[k]=0.0; //initialise
            pErrorSV[k]=0.0;
        }
        //Use FindError function to fill up vectors
        p_symplectic_euler_various_h->FindError(almostNoOfElements+1,pErrorSE);
        p_stoermer_verlet_various_h->FindError(almostNoOfElements+1,pErrorSV);
        //Vectors now has L2-norms of e_h^n vectors for every t, need max.
        double maximumSE=pErrorSE[0]; //initialise
        double maximumSV=pErrorSV[0];
        for (int j=0; j<=almostNoOfElements;j++) //find the maximum in errors
        {
            if (pErrorSE[j]>maximumSE)
            {
                maximumSE=pErrorSE[j]; //update maximum
            }
            if (pErrorSV[j]>maximumSV)
            {
                maximumSV=pErrorSV[j]; //update maximum
            }
        }
        errorsSE_file << h << " " << maximumSE << "\n"; //write to files
        errorsSV_file << h << " " << maximumSV << "\n";
        delete pErrorSE; //deallocate storage
        delete pErrorSV;
        delete p_symplectic_euler_various_h;
        delete p_stoermer_verlet_various_h;
        h=0.5*h; //halve h
        almostNoOfElements=almostNoOfElements*2; //update number of elements
    }
    errorsSE_file.close(); //close the files with values of h and errors
    errorsSV_file.close();
    delete pODESystem;
    delete p_symplectic_euler;
    delete p_stoermer_verlet;
    return 0;
}
