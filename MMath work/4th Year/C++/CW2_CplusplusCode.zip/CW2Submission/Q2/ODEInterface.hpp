#ifndef ODEINTERFACEHEADERDEF
#define ODEINTERFACEHEADERDEF

class ODEInterface
{

  public:

    // Compute right-hand side (pure virtual)
    virtual void ComputeF( const double t, const double x, double& f ) const = 0;

    // Compute analytical solution
    virtual void ComputeAnalyticSolution( const double t, double& x ) const;

    //Compute solution for velocity (I've added this as extra method)
    virtual void ComputeAnalyticVelocity(const double t,double& v) const;

    //Virtual destructor set to default for use in driver
    virtual ~ODEInterface()=default;

};

#endif
