#include <iostream>
#include <cmath>
#include "NBodyODE.hpp"

//Define specialised constructor
NBodyODE::NBodyODE(const int bodyNumber,Vector* p_Masses,
                   Vector* p_Radii)
{
    //Assign values to members of NBodyODE
    mBodyNumber=bodyNumber;
    mpMasses=p_Masses;
    mpRadii=p_Radii;
}

//Override virtual method to compute the value of f. Note that p_F and p_X in
//the below definitions are 1x3N vectors, each string of 3 elements represents
//the values of x and f for an individual body.
void NBodyODE::ComputeF(const double t, Vector* p_X, Vector* p_F) const
{
    const double G=6.674e-11; //declare gravitational constant
    Vector* p_fi=new Vector(3); //initialise the sum, will be used for each i
    double distance; //declare double for norm
    double multi; //declare multiplier for fi
    Vector* p_difference=new Vector(3); //vector for difference/norm
    for (int i=1;i<=mBodyNumber;i++) //tells us which body i we're on
    {
        for (int j=1;j<=mBodyNumber;j++) //tells us which j in sum we're on
        {
            if (j!=i) //ignore when j=i
            {
                for (int k=1;k<=3;k++) //find difference and norm
                {
                    //3*(i-1)+k is the kth element of ith body position
                    //So difference below is x_j-x_i.
                    (*p_difference)(k)=(*p_X)(3*(j-1)+k)-(*p_X)(3*(i-1)+k);
                }
                distance=p_difference->CalculateNorm(2);
                multi=G/pow(distance,3.0);

                //Can now fill/add to elements in p_fi
                for (int k=1;k<=3;k++)
                {
                    (*p_fi)(k)+=multi*(*mpMasses)(j)*(*p_difference)(k);
                }
            }
        }
        //Now fill appropriate elements of p_F with p_fi sum
        for (int k=1;k<=3;k++)
        {
            (*p_F)(3*(i-1)+k)=(*p_fi)(k); //assign value of f
            (*p_fi)(k)=0.0; //reset p_fi for the next iteration
        }
    }
    //Clean up
    delete p_fi;
    delete p_difference;
}

//Define function to check if a collision between any of the bodies has occurred
bool NBodyODE::DetectCollision(const double t,Vector* p_X) const
{
    bool collisionDetected=false; //initialise boolean variable
    Vector* p_difference=new Vector(3); //initialise distance vector
    double distance; //declare double for Euclidean distance
    double tol; //declare double for tolerance below which two bodies collided
    for (int i=1;i<=mBodyNumber-1;i++) //Nth body covered by these i
    {
        for (int j=1;j<=mBodyNumber-i;j++) //Check with all bodies with j>i
        {
            for (int k=1;k<=3;k++)
            {
                //Find difference between ith and (i+j)th body positions
                (*p_difference)(k)=(*p_X)(3*(i-1)+k)-(*p_X)(3*(i+j-1)+k);
            }
            distance=p_difference->CalculateNorm(2);
            tol=(*mpRadii)(i)+(*mpRadii)(i+j); //distance where bodies collide
            if (distance<=tol) //in this case a collision has occurred
            {
                collisionDetected=true; //update boolean variable
                std::cout << "COLLISION!" << std::endl;
                std::cout << "Bodies " << i << " and " << i+j
                << " collided at time t=" << t << std::endl;
                std::cout << "State of system at collision time is:"
                    << std::endl;
                for (int l=1; l<=mBodyNumber;l++) //Print system at t
                {
                    std::cout << "Body " << l << ":"
                    << p_X->Read(3*(l-1)) << " " //Remember Read() zero-based
                    << p_X->Read(3*(l-1)+1) << " "
                    << p_X->Read(3*(l-1)+2) << std::endl;
                }
            }
        }
    }
    delete p_difference; //clean up
    return collisionDetected; //return the boolean variable
}


