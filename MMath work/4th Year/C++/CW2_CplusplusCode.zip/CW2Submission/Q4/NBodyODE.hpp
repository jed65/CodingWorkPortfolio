#ifndef NBODYODEHEADERDEF
#define NBODYODEHEADERDEF

#include "ODEInterface.hpp"

class NBodyODE:public ODEInterface
{
public:
    //Specialised constructor to set private members
    NBodyODE(const int bodyNumber, Vector* p_Masses,
             Vector* p_Radii);
    void ComputeF(const double t, Vector* p_X, Vector* p_F) const;
    bool DetectCollision(const double t,Vector* p_X) const;
private:
    NBodyODE(); //Hidden default constructor
    int mBodyNumber; //Helpful member for methods
    Vector* mpMasses; //1xN vector to hold masses of bodies
    Vector* mpRadii; //1xN vector to hold the radii of bodies
};

#endif
