#include <iostream>
#include <cmath>
#include <chrono>
#include "Vector.hpp"
#include "NBodyODE.hpp"
#include "StoermerVerletSolver.hpp"

int main(int argc,char* argv[])
{
    //Define the constants we need for the first problem
    const double G=6.674e-11;
    double orbitRadius=3.844e8,earthRadius=6.378e6,moonRadius=1.737e6;
    double earthMass=5.972e24,moonMass=7.342e22;
    //Use formulae to find other values
    double speed=sqrt((G*earthMass)/orbitRadius); //for moon velocity
    double period=sqrt((4.0*pow(M_PI,2.0)*pow(orbitRadius,3.0))/(G*earthMass));
    double h=period/10000.0; //first part asks for 10000 time steps
    //Initialise positions and velocity, Earths set to zero, now able to move
    Vector* p_initialState=new Vector(6); //vectors contain info for both bodies
    Vector* p_initialVelocity=new Vector(6);
    (*p_initialState)(4)=orbitRadius; //set initial position of moon
    (*p_initialVelocity)(5)=speed; //set initial velocity of moon
    //Form mass and radii vectors to pass to NBodyODE
    Vector* p_Masses=new Vector(2);
    (*p_Masses)(1)=earthMass; (*p_Masses)(2)=moonMass; //set elements
    Vector* p_Radii=new Vector(2);
    (*p_Radii)(1)=earthRadius; (*p_Radii)(2)=moonRadius;
    //Now can move on to defining class objects and solving system
    ODEInterface* pODESystem=new NBodyODE(2,p_Masses,p_Radii);
    StoermerVerletSolver* p_stoermer_moonAndEarth=
    new StoermerVerletSolver(pODESystem,p_initialState,p_initialVelocity,
                             0.0,period,h,"output4bMoonAndEarth.dat",10,1000);
    p_stoermer_moonAndEarth->Solve(); //solve, print and save

    //Part 2, I use 6 bodies: 3 satellites, one moon, the earth and an asteroid.
    Vector* p_Masses2=new Vector(6);
    (*p_Masses2)(1)=earthMass;
    (*p_Masses2)(2)=moonMass;
    (*p_Masses2)(3)=4.2e5; //this body is the International Space Station
    (*p_Masses2)(4)=282.0; //this is a Meteosat weather satellite
    (*p_Masses2)(5)=680.0; //this is an Iridium telephone satellite
    (*p_Masses2)(6)=4.6e17; //upper bound for weight of dino-killing asteroid
    Vector* p_Radii2=new Vector(6);
    (*p_Radii2)(1)=earthRadius;
    (*p_Radii2)(2)=moonRadius;
    (*p_Radii2)(3)=109.0/2.0; //half of max dimension of ISS
    (*p_Radii2)(4)=3.195/2.0;
    (*p_Radii2)(5)=2.0;
    (*p_Radii2)(6)=6000.0; //half width of asteroid killing dinosaurs
    Vector* p_initialState2=new Vector(18);
    Vector* p_initialVelocity2=new Vector(18);
    //Distances below found online
    (*p_initialState2)(4)=3.90778e8; //actual distance between Earth/Moon COMs
    (*p_initialState2)(7)=6.478e6; //distance between Earth/ISS COMs
    (*p_initialState2)(10)=4.2178e7; //distance between Earth/Meteosat COMs
    (*p_initialState2)(13)=7.148e6; //distance between Earth/Iridium COMs
    (*p_initialState2)(16)=2.5e8; //start the asteroid some distance away
    //Velocities found using formula from q3 and the above
    (*p_initialVelocity2)(5)=1009.922267; //moon velocity
    (*p_initialVelocity2)(8)=7843.908679; //ISS velocity
    (*p_initialVelocity2)(11)=3074.043505; //Meteosat velocity
    (*p_initialVelocity2)(14)=7467.25064; //Iridium velocity
    ODEInterface* pAsteroidSystem=new NBodyODE(6,p_Masses2,p_Radii2);
    StoermerVerletSolver* p_stoermer_asteroid=
    new StoermerVerletSolver(pAsteroidSystem,p_initialState2,p_initialVelocity2,
                             0.0,2.5e5,50,"output4bAsteroid.dat",1,1000);
    p_stoermer_asteroid->Solve();

    //Clean up all of this so we can reuse names (makes it more readable) in iii
    delete p_initialState;
    delete p_initialVelocity;
    delete p_Masses;
    delete p_Radii;
    delete p_initialState2;
    delete p_initialVelocity2;
    delete p_Masses2;
    delete p_Radii2;
    delete pODESystem;
    delete p_stoermer_moonAndEarth;
    delete pAsteroidSystem;
    delete p_stoermer_asteroid;

    //Part 3 code given below
    //For accurate time, comment out initial print/save/header/footer in Solve()
    //and comment out the solvers above. Doing this gives output in latex file.
    int N=2; double radius; double velocity;
    for (int i=1;i<=6;i++)
    {
        radius=orbitRadius+earthRadius; //reset radius to that from ii
        Vector* p_Masses=new Vector(N); //allocate vectors of appropriate size
        (*p_Masses)(1)=earthMass; (*p_Masses)(2)=moonMass; //first 2 bodies
        Vector* p_Radii=new Vector(N);
        (*p_Radii)(1)=earthRadius; (*p_Radii)(2)=moonRadius;
        for (int k=3;k<=N;k++)
        {
            (*p_Masses)(k)=250.0; //set all other masses to 250kg
            (*p_Masses)(k)=2.0; //set all radii equal to 2 metres
        }
        Vector* p_initialPosition=new Vector(3*N); //initialise vectors
        Vector* p_initialVelocity=new Vector(3*N);
        (*p_initialPosition)(4)=radius; (*p_initialVelocity)(5)=1009.922267;
        radius=radius/1.3; //divide by big factor first so no collision w/ moon
        if (N!=2)
        {
            for (int k=1;k<=N/2-1;k++)
            {
                velocity=sqrt((G*earthMass)/radius); //find velocity associated
                (*p_initialPosition)(7+6*(k-1))=radius; //set (radius,0,0) pos.
                (*p_initialPosition)(10+6*(k-1))=(-1.0)*radius; //(-radius,0,0)
                (*p_initialVelocity)(8+6*(k-1))=velocity; //set velocity
                (*p_initialVelocity)(11+6*(k-1))=(-1.0)*velocity;
                radius=radius/1.1; //divide radius by 1.1 for positions
            }
        }
        ODEInterface* pODESystem=new NBodyODE(N,p_Masses,p_Radii);
        StoermerVerletSolver* p_stoermer_verlet=
        new StoermerVerletSolver(pODESystem,p_initialPosition,p_initialVelocity,
                                 0.0,period,h,"LargerBodySystem.dat",100000,
                                 100000);
        // Store the initial time point in t0
        std::chrono::high_resolution_clock::time_point t0
        =std::chrono:: high_resolution_clock::now();
        p_stoermer_verlet->Solve(); //Time the solver
        // Store the final time point in t1
        std::chrono::high_resolution_clock::time_point t1
        = std::chrono::high_resolution_clock::now();
        std::cout << std::endl << " Time elapsed for N=" << N << " is:"
        << std::chrono::duration_cast <std::chrono::milliseconds>(t1-t0).count()
        << " milliseconds " << std::endl;
        //Clean up
        delete p_Masses;
        delete p_Radii;
        delete p_initialVelocity;
        delete p_initialPosition;
        delete pODESystem;
        delete p_stoermer_verlet;
        N=2*N; //update N
    }
    return 0;
}
