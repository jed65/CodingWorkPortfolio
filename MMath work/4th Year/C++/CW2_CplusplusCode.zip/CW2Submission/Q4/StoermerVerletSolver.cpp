#include <iostream>
#include <cassert>
#include <string>
#include <cmath>
#include "StoermerVerletSolver.hpp"

//Specialised constructor defined in same way, Vector* members have length 3N
StoermerVerletSolver::
    StoermerVerletSolver(ODEInterface* pODESystem, const Vector* pInitialState,
                        const Vector* pInitialVelocity, const double initialTime,
                        const double finalTime, const double stepSize,
                        const std::string outputFileName,
                        const int saveGap, const int printGap)
{
    //First set the values of elements inherited from base class
    assert((initialTime>=0) && (finalTime>=0)); //times are non-negative
    assert(finalTime>initialTime); //final time should be bigger than initial
    assert(stepSize>0); //step size should also be positive
    mInitialTime=initialTime; //allocate values to the private members
    mFinalTime=finalTime;
    mStepSize=stepSize;
    mpODESystem=pODESystem;

    //Allocate values to the other private variables
    mpInitialState=pInitialState;
    mpInitialVelocity=pInitialVelocity;
    mOutputFileName=outputFileName;
    mSaveGap=saveGap;
    mPrintGap=printGap;
}


//Override inherited function that solves, prints and saves to file
//Not much to change, PrintElements/SaveElements altered in AbstractODESolver
void StoermerVerletSolver::Solve()
{
    double t=mInitialTime; //for readability
    int noOfElements=mpInitialState->GetSize(); //get length of initial state
    Vector* p_x=new Vector(noOfElements); //allocate space to x vector
    (*p_x)=(*mpInitialState); //initialise, each set of 3 elements is a body
    Vector* p_v=new Vector(noOfElements); //repeat for velocity
    (*p_v)=(*mpInitialVelocity);
    double h=mStepSize; //for readability
    Vector* p_fn=new Vector(noOfElements); //declare vectors for right-hand side
    Vector* p_fnplus=new Vector(noOfElements); //for t_(n+1)
    PrintHeader("Stoermer-Verlet method");
    bool collisionCheck=mpODESystem->DetectCollision(t,p_x); //check collision
    PrintElements(t,p_x,true); //print column names and first row
    SaveElements(t,p_x,mOutputFileName); //save initial positions to file
    //Now implement the method
    int counter=1;
    while (t<=mFinalTime)
    {
        if (collisionCheck==false)
        {
            //Way I've written methods means this part doesn't need altering
            mpODESystem->ComputeF(t,p_x,p_fn); //update value of fn
            t=t+h; //go to next time point
            for (int i=1;i<=noOfElements;i++) //1-based indexing
            {
                (*p_x)(i)+=h*(*p_v)(i)+0.5*pow(h,2.0)*(*p_fn)(i); //update
            }
            mpODESystem->ComputeF(t,p_x,p_fnplus); //update value of fnplus
            for (int i=1;i<=noOfElements;i++)
            {
                (*p_v)(i)+=0.5*h*((*p_fn)(i)+(*p_fnplus)(i)); //update
            }
            if (counter%mPrintGap==0) //if counter divisible by PrintGap, print
            {
                PrintElements(t,p_x); //print positions to the screen
            }
            if (counter%mSaveGap==0) //if counter divisible by SaveGap, save
            {
                SaveElements(t,p_x,mOutputFileName); //save positions to file
            }
            counter++;
        }
        else //collision has occurred, details printed to screen
        {
            break; //exit while loop
        }
        collisionCheck=mpODESystem->DetectCollision(t,p_x); //check collision
    }
    std::cout << "-------------------------------------------------------------"
            << "-------------------------------"
    << std::endl; //Fancy footer
    delete p_x; //clean up
    delete p_v;
    delete p_fn;
    delete p_fnplus;
}
