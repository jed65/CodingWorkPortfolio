#ifndef ODEINTERFACEHEADERDEF
#define ODEINTERFACEHEADERDEF

#include "Vector.hpp"

class ODEInterface
{

  public:

    // Compute right-hand side (pure virtual)
    virtual void ComputeF( const double t, Vector* p_X, Vector* p_F )
    const = 0;

    // Declare pure virtual to detect collision here (so can use in solvers)
    virtual bool DetectCollision(const double t,Vector* p_X) const=0;

    //Virtual destructor
    virtual ~ODEInterface()=default;

    // Compute analytical solution
    //virtual void ComputeAnalyticSolution( const double t, double x ) const;

};

#endif
