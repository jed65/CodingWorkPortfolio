#include <iostream>
#include <cassert>
#include <fstream>
#include <iomanip>
#include <sstream>
#include <string>

#include "AbstractODESolver.hpp"

//Function to print an initial header to console
void AbstractODESolver::PrintHeader(const std::string methodName) const
{
    std::cout << "-------------------------------------------------------------"
            << "-------------------------------"
            << std::endl
            << " Attempt to numerically solve ODE using " + methodName
            << std::endl
	    << " in the domain [" << mInitialTime << "," << mFinalTime << "]"
            << std::endl
	    << " with stepsize = " << mStepSize
            << std::endl
            << "-------------------------------------------------------------"
            << "-------------------------------"
            << std::endl;
}

//Function to print positions of bodies
void AbstractODESolver::PrintElements(const double t, const Vector* p_x,
                                      const bool initialise) const
{
    int N=p_x->GetSize()/3; //this is number of bodies in system
    // At first time, label the columns
  if (initialise)
  {
    std::cout << "t            ";
    for (int i=1;i<=N;i++) //Just printing states of system, ignoring velocity
    {
        std::cout << " x" << i << "(1)";
        std::cout << "        ";
        std::cout << " x" << i << "(2)";
        std::cout << "        ";
        std::cout << " x" << i << "(3)";
        std::cout << "        ";
    }
    std::cout << std::endl;
  }
  // Fill a row with the values
  std::cout << t << " "
            << std::scientific
            << std::setprecision(6); //Set higher level of precision
  for (int i=1;i<=N;i++) //Remember that Read() is zero-indexed
  {
      std::cout << p_x->Read(3*(i-1)) << "  ";
      std::cout << p_x->Read(3*(i-1)+1) << "  ";
      std::cout << p_x->Read(3*(i-1)+2) << "  ";
  }
  std::cout << std::endl;
}

//Function to save specific elements t and state of system to a file.
void AbstractODESolver::SaveElements(const double t, const Vector* p_x,
                                     const std::string outputFileName) const
{
  //Declare output stream and give file higher precision
  std::ofstream output_file;
  output_file.setf(std::ios::scientific,std::ios::floatfield);
  output_file.precision(6);
  //Open file we want to append
  output_file.open(outputFileName,std::ios::app);
  assert(output_file.is_open()); //check open
  //Write data to file
  output_file << t << " ";
  for (int i=0;i<p_x->GetSize();i++) //save values from vector x to file
  {
      output_file << p_x->Read(i) << " "; //writes in all 3N elements
  }
  output_file << "\n";
  output_file.close(); //close the file once data written to it
}
