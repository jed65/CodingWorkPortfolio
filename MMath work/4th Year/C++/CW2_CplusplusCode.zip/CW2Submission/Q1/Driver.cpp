#include <iostream>
#include <fstream>
#include <cassert>
#include "OscillatorODE.hpp"
#include "ForwardEulerSolver.hpp"

int main(int argc, char* argv[])
{
    //First define and allocate storage to ODESystem
    ODEInterface* pODESystem=new OscillatorODE(1.5); //a set equal to 1.5
    //Next define and allocate storage to the forward Euler system
    ForwardEulerSolver* p_forward_euler=
    new ForwardEulerSolver(pODESystem,0.0,1.5,0.0,30.0,0.01,"output.dat",1,100);
    p_forward_euler->Solve(); //Call the Solve() method to solve the system
    //Note that I deliberately chose mPrintGap=100 so output suitable size
    //for the latex file, gives values at t=0,1,...,30 from h=0.01

    //Next vary values of h and look at error
    double h=0.2; //initial value of h which we will continuously half
    int almostNoOfElements=5; //this is 1/h
    //double* p_max_error=new double[7]; //vector for the errors E(h) (CHECK)
    //Set up file to store h and E(h)
    std::ofstream errors_file; //define output stream for errors file
    errors_file.setf(std::ios::scientific,std::ios::floatfield);
    errors_file.precision(6); //these lines ensure high precision
    errors_file.open("errors1d.dat"); //open file
    assert(errors_file.is_open()); //check that file is open
    //Now find E(h) for each h and write them to the file
    for (int i=1;i<=10;i++)
    {
        //Declare new forward Euler system
        ForwardEulerSolver* p_forward_euler_various_h=
        new ForwardEulerSolver(pODESystem,0.0,1.5,0.0,1.0,h);
        double* pError; //Declare error vector
        pError=new double[almostNoOfElements+1]; //allocate storage
        for (int k=0; k<=almostNoOfElements;k++)
        {
            pError[k]=0.0; //initialise
        }
        //Use FindError function to fill up pError
        p_forward_euler_various_h->FindError(almostNoOfElements+1,pError);
        //pError now has L2-norms of e_h^n vectors for every t, need max.
        double maximum=pError[0];
        for (int j=0; j<=almostNoOfElements;j++) //find the maximum in pError
        {
            if (pError[j]>maximum)
            {
                maximum=pError[j]; //update maximum
            }
        }
        errors_file << h << " " << maximum << "\n"; //write to file
        //The lines with p_max_error are part of checks, commented out
        //p_max_error[i-1]=maximum; //this is E(h)
        //std::cout << "When h=" << h << ", E(h)=" << maximum << std::endl;
        delete pError; //deallocate storage of pError
        delete p_forward_euler_various_h;
        h=0.5*h; //halve h
        almostNoOfElements=almostNoOfElements*2; //update number of elements
    }
    errors_file.close(); //close the file with values of h and errors
    //delete p_max_error; //This is part of the check
    delete pODESystem;
    delete p_forward_euler;
    return 0;
}
