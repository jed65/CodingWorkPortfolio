#ifndef ABSTRACTODESOLVERHEADERDEF //if not already defined, execute below code
#define ABSTRACTODESOLVERHEADERDEF //define the macro

#include "ODEInterface.hpp" //protected member is from ODEInterface

class AbstractODESolver
{
public:
    //Purely virtual function (set =0), no need to put in source file
    virtual void Solve()=0;

    //Print initial header
    virtual void PrintHeader(const std::string methodName) const;

    //Print specific element
    virtual void PrintElements(const double t, const double x, const double v,
                               const bool initialise=false) const;

    //Append specific element to file
    virtual void SaveElements(const double t, const double x, const double v,
                              const std::string outputFileName) const;

    //Virtual destructor set to default so we can use delete in driver w/o error
    virtual ~AbstractODESolver()=default;

    //Pure virtual method used to calculate the error in the solver
    virtual void FindError(const int noOfElements,double* pError)=0;

protected: //define protected members of class here
    double mInitialTime;
    double mFinalTime;
    double mStepSize;
    ODEInterface* mpODESystem;
};


#endif //close statement
