#include "ODEInterface.hpp"

void ODEInterface::ComputeAnalyticSolution( const double t, double& x ) const
{
}

void ODEInterface::ComputeAnalyticVelocity(const double t,double& v) const
{
}
