#ifndef FORWARDEULERSOLVERHEADERDEF
#define FORWARDEULERSOLVERHEADERDEF

#include "AbstractODESolver.hpp" //derived from this abstract class

class ForwardEulerSolver: public AbstractODESolver
{
 public:
     //Public constructor
     ForwardEulerSolver(ODEInterface* pODESystem, const double initialState,
                        const double initialVelocity, const double initialTime,
                        const double finalTime, const double stepSize,
                        const std::string outputFileName="output.dat",
                        const int saveGap=1, const int printGap=1);
    //Override solve
    void Solve();
    //Method to find error
    void FindError(const int noOfElements, double* pError);
 private:
    double mInitialState; //add some elements we need that aren't inherited
    double mInitialVelocity;
    std::string mOutputFileName;
    int mSaveGap;
    int mPrintGap;

};







#endif
