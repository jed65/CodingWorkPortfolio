#include <iostream>
#include <cmath>
#include "OscillatorODE.hpp"

//Define the specialised constructor
OscillatorODE::OscillatorODE(const double initialVelocity)
{
    //There are no members inherited from ODEInterface

    //Assign value to private member of OscillatorODE
    mInitialVelocity=initialVelocity;
}

//Override method to compute value of f, which is passed by reference
void OscillatorODE::ComputeF(const double t,const double x,double& f) const
{
    f=(-1.0)*pow(mInitialVelocity,2.0)*x; //use f(t,x(t))=-a^2*x given
}

//Next override method for computing the analytic solution, x reference variable
void OscillatorODE::ComputeAnalyticSolution(const double t,double& x) const
{
    x=sin(mInitialVelocity*t); //use x(t)=sin(at) given
}


void OscillatorODE::ComputeAnalyticVelocity(const double t,double& v) const
{
    v=mInitialVelocity*cos(mInitialVelocity*t); //derivative of x(t)
}
