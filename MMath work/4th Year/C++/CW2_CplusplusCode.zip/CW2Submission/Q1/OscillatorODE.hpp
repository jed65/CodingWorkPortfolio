#ifndef OSCILLATORODEHEADERDEF //if not already defined, execute below code
#define OSCILLATORODEHEADERDEF

#include "ODEInterface.hpp" //overriding functions within this class

class OscillatorODE: public ODEInterface //class derived from ODEInterface
{
public:
    OscillatorODE(const double initialVelocity); //Specialised constructor
    void ComputeF(const double t,const double x,double& f) const; //Override
    void ComputeAnalyticSolution(const double t,double& x) const; //Override
    void ComputeAnalyticVelocity(const double t,double& v) const; //Override
private:
    OscillatorODE(); //Hidden default constructor
    double mInitialVelocity; //need this to be able to evaluate above functions
};


#endif //close statement
