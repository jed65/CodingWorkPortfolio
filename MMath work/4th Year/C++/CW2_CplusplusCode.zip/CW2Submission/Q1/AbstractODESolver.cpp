#include <iostream>
#include <cassert>
#include <fstream>
#include <iomanip>
#include <sstream>
#include <string>

#include "AbstractODESolver.hpp"

//Function to print an initial header to console
void AbstractODESolver::PrintHeader(const std::string methodName) const
{
    std::cout << "-------------------------------------------------------------"
            << "-------------------------------"
            << std::endl
            << " Attempt to numerically solve ODE using " + methodName
            << std::endl
	    << " in the domain [" << mInitialTime << "," << mFinalTime << "]"
            << std::endl
	    << " with stepsize = " << mStepSize
            << std::endl
            << "-------------------------------------------------------------"
            << "-------------------------------"
            << std::endl;
}

//Function to print a set of elements
void AbstractODESolver::PrintElements(const double t, const double x,
                                      const double v,
                                      const bool initialise) const
{
    // At first time, label the columns
  if (initialise)
  {
    std::cout << std::setw(10) << "t"
              << std::setw(25) << "x"
              << std::setw(40) << "v"
              << std::endl;
  }

  // Fill a row with the values
  std::cout << std::setw(10) << t
            << std::scientific
            << std::setprecision(6) //Set higher level of precision
            << std::setw(25) << x
            << std::setw(40) << v
            << std::endl;
}

//Function to save specific elements t,x,v to a file
void AbstractODESolver::SaveElements(const double t, const double x,
                                     const double v,
                                     const std::string outputFileName) const
{
  //Declare output stream and give file higher precision
  std::ofstream output_file;
  output_file.setf(std::ios::scientific,std::ios::floatfield);
  output_file.precision(6);
  //Open file we want to append
  output_file.open(outputFileName,std::ios::app);
  assert(output_file.is_open()); //check open
  //Write data to file
  output_file << t << " " << x << " " << v << "\n";
  output_file.close(); //close the file once data written to it
}
