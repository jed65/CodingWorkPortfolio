#ifndef ODEINTERFACEHEADERDEF
#define ODEINTERFACEHEADERDEF

#include "Vector.hpp"

class ODEInterface
{

  public:

    // Compute right-hand side (pure virtual)
    virtual void ComputeF( const double t, const Vector* p_x, Vector* p_f )
    const = 0;

    // Declare pure virtual to detect collision here (so can use in solvers)
    virtual bool DetectCollision(const double t, const Vector* p_x) const=0;

    //Add virtual destructor
    virtual ~ODEInterface()=default;

    // Compute analytical solution
    //virtual void ComputeAnalyticSolution( const double t, double x ) const;

};

#endif
