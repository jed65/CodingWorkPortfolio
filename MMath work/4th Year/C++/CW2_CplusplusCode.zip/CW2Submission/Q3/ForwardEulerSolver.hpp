#ifndef FORWARDEULERSOLVERHEADERDEF
#define FORWARDEULERSOLVERHEADERDEF

#include "AbstractODESolver.hpp" //derived from this abstract class

class ForwardEulerSolver: public AbstractODESolver
{
 public:
     //Public constructor
     ForwardEulerSolver(ODEInterface* pODESystem, const Vector* pInitialState,
                        const Vector* pInitialVelocity,const double initialTime,
                        const double finalTime, const double stepSize,
                        const std::string outputFileName="output.dat",
                        const int saveGap=1, const int printGap=1);
    //Override solve
    void Solve();
    //Method to find error removed, could add back in later to test method
 private:
    const Vector* mpInitialState; //add some elements we need
    const Vector* mpInitialVelocity;
    std::string mOutputFileName;
    int mSaveGap;
    int mPrintGap;

};







#endif
