#include <iostream>
#include <cmath>
#include "Vector.hpp"
#include "OrbitODE.hpp"
#include "ForwardEulerSolver.hpp"
#include "SymplecticEulerSolver.hpp"
#include "StoermerVerletSolver.hpp"

int main(int argc, char* argv[])
{
    //Define the constants we need for this problem
    const double G=6.674e-11;
    double orbitRadius=3.844e8,fixedRadius=6.378e6,movingRadius=1.737e6;
    double fixedMass=5.972e24; //fixed body is Earth, moving is Moon

    //Use formulae and info given in question to form other elements of problem
    double speed=sqrt((G*fixedMass)/orbitRadius); //use formulae given
    double period=sqrt((4.0*pow(M_PI,2.0)*pow(orbitRadius,3.0))/(G*fixedMass));
    double h=period/10000.0; //first part asks for 10000 time steps
    Vector* p_initialState=new Vector(3); //initialise with zeroes
    Vector* p_initialVelocity=new Vector(3);
    Vector* p_fixedPosition=new Vector(3); //position of Earth COM is the origin
    (*p_initialState)(1)=orbitRadius; //change first element to match given
    (*p_initialVelocity)(2)=speed; //change second element to match given

    //Now can move on to defining class objects and solving system
    ODEInterface* pODESystem=new OrbitODE(fixedMass,p_fixedPosition,fixedRadius,
                                          movingRadius);
    ForwardEulerSolver* p_forward_euler=new ForwardEulerSolver(pODESystem,
                                        p_initialState,p_initialVelocity,
                                        0.0,period,h,"output3bFE.dat",10,1000);
    //Note here I put printGap=100, should get 101 time points printed
    p_forward_euler->Solve(); //call to print solution/save to file
    //Repeat for the other two methods
    SymplecticEulerSolver* p_symplectic_euler=
    new SymplecticEulerSolver(pODESystem,p_initialState,p_initialVelocity,0.0,
                              period,h,"output3bSE.dat",10,1000);
    p_symplectic_euler->Solve();
    StoermerVerletSolver* p_stoermer_verlet=
    new StoermerVerletSolver(pODESystem,p_initialState,p_initialVelocity,0.0,
                             period,h,"output3bOne_k.dat",10,1000);
    p_stoermer_verlet->Solve();

    //Second part asks us to find the collision time using chosen method.
    //Pass the initial velocity as p_fixedPosition as this is already
    //zero vector. h=50 chosen first as less than a minute so should give a good
    //idea of the time to begin with, T=2500000 also chosen as large time.
    //Running with this stepsize and final time gave a collision at
    //t=4.188e5. Repeat implementation with T=500000 and stepsize h=10 should
    //give a far more accurate result with similar computation time.
    //Indeed gives collision at t=4.1876e5, which is 6979 minutes, 20 seconds.
    StoermerVerletSolver* p_stoermer_verlet_part2=
    new StoermerVerletSolver(pODESystem,p_initialState,p_fixedPosition,0.0,
                             500000.0,10.0,"output3bZero_k.dat",10,5000);
    p_stoermer_verlet_part2->Solve();
    //Last part asks us to try different values for initial velocity. k=0 and
    //k=1 have already been done. On top of these, try k=1/2,k=2.
    (*p_initialVelocity)(2)=0.5*speed; //k=1/2
    StoermerVerletSolver* p_stoermer_verlet_kHalf=
    new StoermerVerletSolver(pODESystem,p_initialState,p_initialVelocity,0.0,
                             period,h,"output3bHalf_k.dat",10,1000);
    p_stoermer_verlet_kHalf->Solve();
    (*p_initialVelocity)(2)=2*speed; //k=2
    StoermerVerletSolver* p_stoermer_verlet_kTwo=
    new StoermerVerletSolver(pODESystem,p_initialState,p_initialVelocity,0.0,
                             period,h,"output3bTwo_k.dat",10,1000);
    p_stoermer_verlet_kTwo->Solve();
    delete p_initialState;
    delete p_initialVelocity;
    delete p_fixedPosition;
    delete pODESystem;
    delete p_forward_euler;
    delete p_symplectic_euler;
    delete p_stoermer_verlet;
    delete p_stoermer_verlet_part2;
    delete p_stoermer_verlet_kHalf;
    delete p_stoermer_verlet_kTwo;
    return 0;
}
