#ifndef ABSTRACTODESOLVERHEADERDEF //if not already defined, execute below code
#define ABSTRACTODESOLVERHEADERDEF //define the macro

#include "ODEInterface.hpp" //protected member is from ODEInterface
#include "Vector.hpp" //use Vector in functions

class AbstractODESolver
{
public:
    //Purely virtual function (set =0), no need to put in source file
    virtual void Solve()=0;

    //Print initial header
    virtual void PrintHeader(const std::string methodName) const;

    //Print specific element
    virtual void PrintElements(const double t, const Vector* p_x,
                               const Vector* p_v,
                               const bool initialise=false) const;

    //Append specific element to file
    virtual void SaveElements(const double t, const Vector* p_x,
                              const Vector* p_v,
                              const std::string outputFileName) const;

    //Add virtual destructor
    virtual ~AbstractODESolver()=default;

protected: //define protected members of class here
    double mInitialTime;
    double mFinalTime;
    double mStepSize;
    ODEInterface* mpODESystem;
};


#endif //close statement
