#include <iostream>
#include <cmath>
#include "OrbitODE.hpp"

//Define the specialised constructor
OrbitODE::OrbitODE(const double fixedMass, const Vector* p_fixedPosition,
                   const double fixedRadius, const double movingRadius)
{
    //There are no members inherited from ODEInterface

    //Assign value to private members of OrbitODE
    mFixedMass=fixedMass;
    mpFixedPosition=p_fixedPosition;
    mFixedRadius=fixedRadius;
    mMovingRadius=movingRadius;
}

//Override method to compute value of f, which is passed by reference
void OrbitODE::ComputeF(const double t,const Vector* p_x, Vector* p_f) const
{
    const double G=6.674e-11; //declare gravitational constant
    Vector* p_difference=new Vector(3);
    (*p_difference)=(*mpFixedPosition)-(*p_x); //assign values to the difference
    double distance=p_difference->CalculateNorm(2); //calculate Euclidean dist.
    double multiplier=(G*mFixedMass)/pow(distance,3.0);
    for (int i=1;i<=p_f->GetSize();i++)
    {
        (*p_f)(i)=multiplier*(*p_difference)(i); //use formula
    }
    delete p_difference;
}


//Method is defined here as the possibility of a collision is specific to this
//problem/system, it doesn't make sense to put it in a different class. Since
//this method is specific for orbits, and the requirements of such a method
//include positions/radii/mass most of which were already included in this class
//, it makes even more sense that the method should be placed here.
//Note that the Solvers each contain a ODEInterface member, so for us to use
//this method within the overridden Solve() function, we also need to define
//this as a pure virtual method in ODEInterface.hpp
bool OrbitODE::DetectCollision(const double t, const Vector* p_x) const
{
    bool collisionDetected;
    //Calculate distance between the centres of mass mFixedPosition/x
    Vector* p_difference=new Vector(3);
    (*p_difference)=(*mpFixedPosition)-(*p_x); //assign values to the difference
    double distance=p_difference->CalculateNorm(2); //calculate Euclidean dist.
    //Define distance at which there is collision
    double collideTol=mFixedRadius+mMovingRadius;
    //If distance less than/equal to collideTol, then there has been collision
    if (distance<=collideTol)
    {
        //In this case, we have a collision
        collisionDetected=true;
        std::cout << "COLLISION!" << std::endl;
        std::cout << "Bodies collided at time t=" << t << std::endl;
        std::cout << "State x of moving body upon collision is:" << std::endl;
        std::cout << p_x->Read(0) << " " << p_x->Read(1) << " " << p_x->Read(2)
        << std::endl;
    }
    else
    {
        //In this case, there is no collision
        collisionDetected=false;
    }
    return collisionDetected; //return the boolean variable
}
