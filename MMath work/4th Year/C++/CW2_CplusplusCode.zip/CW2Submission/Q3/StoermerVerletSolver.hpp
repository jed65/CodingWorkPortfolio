#ifndef STOERMERVERLETSOLVERHEADERDEF
#define STOERMERVERLETSOLVERHEADERDEF

#include "AbstractODESolver.hpp" //derived from this abstract class
//This header file formed by copy/paste/edit of Forward Euler header
class StoermerVerletSolver: public AbstractODESolver
{
    public:
     //Public constructor, change outputFileName to avoid confusion
     StoermerVerletSolver(ODEInterface* pODESystem, const Vector* pInitialState,
                        const Vector* pInitialVelocity,const double initialTime,
                        const double finalTime, const double stepSize,
                        const std::string outputFileName="outputSV.dat",
                        const int saveGap=1, const int printGap=1);
    //Override solve
    void Solve();
    //Method to find error removed
 private:
    const Vector* mpInitialState; //add some elements that aren't inherited
    const Vector* mpInitialVelocity;
    std::string mOutputFileName;
    int mSaveGap;
    int mPrintGap;
};

#endif
