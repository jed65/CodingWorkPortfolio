#include <iostream>
#include <cassert>
#include <fstream>
#include <iomanip>
#include <sstream>
#include <string>

#include "AbstractODESolver.hpp"

//Function to print an initial header to console
void AbstractODESolver::PrintHeader(const std::string methodName) const
{
    std::cout << "-------------------------------------------------------------"
            << "-------------------------------"
            << std::endl
            << " Attempt to numerically solve ODE using " + methodName
            << std::endl
	    << " in the domain [" << mInitialTime << "," << mFinalTime << "]"
            << std::endl
	    << " with stepsize = " << mStepSize
            << std::endl
            << "-------------------------------------------------------------"
            << "-------------------------------"
            << std::endl;
}

//Function to print a set of elements
void AbstractODESolver::PrintElements(const double t, const Vector* p_x,
                                      const Vector* p_v,
                                      const bool initialise) const
{
    // At first time, label the columns
  if (initialise)
  {
    std::cout << std::setw(12) << " t"
              << std::setw(12) << " x(1)"
              << std::setw(12) << " x(2)"
              << std::setw(12) << " x(3)"
              << std::setw(12) << " v(1)"
              << std::setw(12) << " v(2)"
              << std::setw(12) << " v(3)"
              << std::endl;
  }
  // Fill a row with the values
  std::cout << t << " "
            << std::scientific
            << std::setprecision(6) //Set higher level of precision
            << p_x->Read(0) << " " << p_x->Read(1) << " " <<
            p_x->Read(2) << " " << p_v->Read(0) << " " << p_v->Read(1)
            << " " << p_v->Read(2) << std::endl;
}

//Function to save specific elements t,x,v to a file.
void AbstractODESolver::SaveElements(const double t, const Vector* p_x,
                                     const Vector* p_v,
                                     const std::string outputFileName) const
{
  //Declare output stream and give file higher precision
  std::ofstream output_file;
  output_file.setf(std::ios::scientific,std::ios::floatfield);
  output_file.precision(6);
  //Open file we want to append
  output_file.open(outputFileName,std::ios::app);
  assert(output_file.is_open()); //check open
  //Write data to file
  output_file << t << " ";
  for (int i=0;i<p_x->GetSize();i++) //save values from vector x to file
  {
      output_file << p_x->Read(i) << " ";
  }
  for (int i=0;i<p_v->GetSize();i++) //save values from vector v to file
  {
      output_file << p_v->Read(i) << " ";
  }
  output_file << "\n";
  output_file.close(); //close the file once data written to it
}
