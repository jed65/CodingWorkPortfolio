#include "ODEInterface.hpp"

//void ODEInterface::ComputeAnalyticSolution( const double t, double x ) const
//{
//}
