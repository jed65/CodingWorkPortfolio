#include <iostream>
#include <cassert>
#include <string>
#include <cmath>
#include "StoermerVerletSolver.hpp"

//Much of this source file has been copy/pasted/edited from Forward Euler source
//Specialised constructor
StoermerVerletSolver::
    StoermerVerletSolver(ODEInterface* pODESystem, const Vector* pInitialState,
                        const Vector* pInitialVelocity, const double initialTime,
                        const double finalTime, const double stepSize,
                        const std::string outputFileName,
                        const int saveGap, const int printGap)
{
    //First set the values of elements inherited from base class
    assert((initialTime>=0) && (finalTime>=0)); //times are non-negative
    assert(finalTime>initialTime); //final time should be bigger than initial
    assert(stepSize>0); //step size should also be positive
    mInitialTime=initialTime; //allocate values to the private members
    mFinalTime=finalTime;
    mStepSize=stepSize;
    mpODESystem=pODESystem;

    //Allocate values to the other private variables
    mpInitialState=pInitialState;
    mpInitialVelocity=pInitialVelocity;
    mOutputFileName=outputFileName;
    mSaveGap=saveGap;
    mPrintGap=printGap;
}

//Biggest changes are for these functions, as the method is different
//Override inherited function that solves, print and save to file
void StoermerVerletSolver::Solve()
{
    //Initialise the variables
    double t=mInitialTime;
    Vector* p_x=new Vector(3);
    (*p_x)=(*mpInitialState); //initialise
    Vector* p_v=new Vector(3);
    (*p_v)=(*mpInitialVelocity); //initialise
    double h=mStepSize; //This is to improve readability
    Vector* p_fn=new Vector(3); //To compute the right hand side at time n
    Vector* p_fnplus=new Vector(3); //Compute the right hand side at time n+1
    PrintHeader("Stoermer-Verlet method"); //Print header (inherited method)
    bool collisionCheck=mpODESystem->DetectCollision(t,p_x); //check collision
    PrintElements(t,p_x,p_v,true); //Print column names then first row
    SaveElements(t,p_x,p_v,mOutputFileName); //Save initial values to file
    //Now implement the method
    int counter=1;
    while (t<=mFinalTime)
    {
        if (collisionCheck==false) //in this case, no collision has occurred
        {
            mpODESystem->ComputeF(t,p_x,p_fn); //Update the value of fn
            t=t+h; //Go to next time point
            for (int i=1;i<=p_x->GetSize();i++) //1-based indexing
            {
                (*p_x)(i)+=h*(*p_v)(i)+0.5*pow(h,2.0)*(*p_fn)(i); //Update
            }
            mpODESystem->ComputeF(t,p_x,p_fnplus); //Update value of fnplus
            for (int i=1;i<=p_v->GetSize();i++)
            {
                (*p_v)(i)+=0.5*h*((*p_fn)(i)+(*p_fnplus)(i)); //Update
            }
            if (counter%mPrintGap==0) //if counter divisible by PrintGap, print
            {
                PrintElements(t,p_x,p_v); //print these elements to the screen
            }
            if (counter%mSaveGap==0) //if counter divisible by SaveGap, save
            {
                SaveElements(t,p_x,p_v,mOutputFileName); //save elements to file
            }
            counter++;
        }
        else //collision has occurred, details printed to screen
        {
            break; //exit while loop
        }
        collisionCheck=mpODESystem->DetectCollision(t,p_x); //check collision
    }
    std::cout << "-------------------------------------------------------------"
            << "-------------------------------"
    << std::endl; //Fancy footer
    delete p_x;
    delete p_v;
    delete p_fn;
    delete p_fnplus;
}
