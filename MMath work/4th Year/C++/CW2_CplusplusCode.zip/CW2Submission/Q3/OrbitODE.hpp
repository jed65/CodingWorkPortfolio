#ifndef ORBITODEHEADERDEF
#define ORBITODEHEADERDEF

#include "ODEInterface.hpp" //overriding functions within this class

class OrbitODE:public ODEInterface
{
public:
    //Specialised constructor depending on parts of fixed body
    OrbitODE(const double fixedMass, const Vector* p_fixedPosition,
             const double fixedRadius, const double movingRadius);
    void ComputeF(const double t, const Vector* p_x, Vector* p_f) const;
    bool DetectCollision(const double t,const Vector* p_x) const; //See .cpp
private:
    OrbitODE(); //hidden default constructor
    double mFixedMass; //need these two to evaluate ComputeF function
    const Vector* mpFixedPosition;
    double mFixedRadius; //need next two for DetectCollision function
    double mMovingRadius;
};

#endif // ORBITODEHEADERDEF
