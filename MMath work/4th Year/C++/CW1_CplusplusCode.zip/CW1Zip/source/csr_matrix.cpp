#include <iostream>
#include <cmath>
#include <string>
#include <cassert>
#include <cstdlib>
#include <fstream>
#include "csr_matrix.hpp"

//1a. is here, also defined in .hpp file but gives redefine struct error when
//both ran, I just removed the struct from this file to stop getting the error.
//I opted to follow the hint given in the coursework but please be assured that
//the code for each question compiles without error if you remove the struct
//from this .cpp file.
//PLEASE REMOVE STRUCT FROM HERE IF YOU GET AN ERROR BEFORE COMPILING
struct csr_matrix
{
    int no_rows; //define number of rows in n x n matrix
    double* matrix_entries; //no restriction for entries to be integers
    int* column_no; //the two vectors tells us where entries are, must be int
    int* row_start;
    bool symmetric; //tells us whether or not the matrix is symmetric
};


csr_matrix SetUpRegularMatrix(int noRows,double** pA)
{
    csr_matrix matrix;
    matrix.no_rows=noRows; //next few lines initialise struct arguments
    matrix.symmetric=false; //this function assumes no symmetry
    matrix.row_start=new int[noRows+1];
    int non_zero_row_count; //to count how many elements non-zero per row
    int* p_row_count; //to keep track of no. of non-zero elements in each row
    p_row_count=new int[noRows]; //needs to go over every row
    for (int i=0;i<noRows;i++)
    {
        non_zero_row_count=0;
        for (int j=0; j<noRows;j++) //we have n x n matrix
        {
            if (fabs(pA[i][j])>1e-10)
            {
                non_zero_row_count++; //if non-zero element in row, add 1
            }
        }
        //assign i-th element of counting vector to no. non-zero in i-th row
        p_row_count[i]=non_zero_row_count;
    }
    matrix.row_start[0]=0; //first row starts from first element of entries
    for (int i=1;i<noRows+1;i++)
    {
        //This for loop allocates row start and finds total number of non-zeroes
        matrix.row_start[i]=matrix.row_start[i-1]+p_row_count[i-1];
    }
    //Final element of row_start gives total number of non-zero elements
    matrix.matrix_entries=new double[matrix.row_start[noRows]]; //allocation
    matrix.column_no=new int[matrix.row_start[noRows]];
    //Now we need to give appropriate values to these
    int keep_up=0; //this will tell us which element of the above to assign to
    for (int i=0;i<noRows;i++)
    {
        for (int j=0;j<noRows;j++)
        {
            if (fabs(pA[i][j])>1e-10)
            {
                matrix.matrix_entries[keep_up]=pA[i][j];
                matrix.column_no[keep_up]=j;
                keep_up++; //move on to next non-zero element
            }
        }
    }
    delete[] p_row_count; //deallocate storage
    return matrix;
}

csr_matrix SetUpSymmetricMatrix(int noRows,double** pA)
{
    csr_matrix matrix;
    matrix.no_rows=noRows; //next few lines initialise struct arguments
    matrix.symmetric=true; //this function assumes we have symmetry
    matrix.row_start=new int[noRows+1];
    //Count number of non-zero elements in upper triangular portion
    int non_zero_row_count;
    int* p_row_count;
    p_row_count=new int[noRows];
    for (int i=0;i<noRows;i++)
    {
        non_zero_row_count=0;
        for (int j=i;j<noRows;j++) //interested in upper portion
        {
            if (fabs(pA[i][j])>1e-10)
            {
                non_zero_row_count++; //count number in each row
            }
        }
        p_row_count[i]=non_zero_row_count; //assign to appropriate element of rowCount
    }
    //Can do next part in same way as regular matrix
    matrix.row_start[0]=0; //first row starts from first element of entries
    for (int i=1;i<noRows+1;i++)
    {
        //This for loop allocates row start and finds total number of non-zeroes
        matrix.row_start[i]=matrix.row_start[i-1]+p_row_count[i-1];
    }
    //Final element of row_start gives total number of non-zero elements
    matrix.matrix_entries=new double[matrix.row_start[noRows]]; //allocation
    matrix.column_no=new int[matrix.row_start[noRows]];
    int keep_up=0; //this will tell us which element of the above to assign to
    for (int i=0;i<noRows;i++)
    {
        for (int j=i;j<noRows;j++) //difference is here, want upper portion
        {
            if (fabs(pA[i][j])>1e-10)
            {
                matrix.matrix_entries[keep_up]=pA[i][j];
                matrix.column_no[keep_up]=j;
                keep_up++; //move on to next non-zero element
            }
        }
    }
    delete[] p_row_count; //deallocate storage
    return matrix;
}

double* MultiplyAx(csr_matrix A,double* pX)
{
    double* pAx;
    pAx=new double[A.no_rows]; //allocate storage for product
    for (int i=0;i<A.no_rows;i++)
    {
        pAx[i]=0.0; //initialise with zeroes
    }
    if (A.symmetric==0) //if regular matrix
    {
        for (int t=0; t<A.no_rows;t++)
        {
            for (int i=A.row_start[t];i<A.row_start[t+1];i++)
            {
                //these values of i ensure correct entries multiplied/added
                pAx[t]+=A.matrix_entries[i]*pX[A.column_no[i]]; //add product
            }
        }
    }
    else //if symmetric matrix
    {
        //Now have problem with off-diagonals
        for (int t=0; t<A.no_rows;t++)
        {
            pAx[t]+=A.matrix_entries[A.row_start[t]]*pX[t]; //add diagonal term
            if (A.row_start[t+1]-A.row_start[t]>1) //i.e. off-diagonals on row
            {
               for (int i=A.row_start[t]+1;i<A.row_start[t+1];i++)
               {
                  pAx[t]+=A.matrix_entries[i]*pX[A.column_no[i]]; //add off-di
                  pAx[A.column_no[i]]+=A.matrix_entries[i]*pX[t]; //add later
               }
            }
        }
    }
    return pAx;
}

void PrintVectors(csr_matrix matrix)
{
    //Function to check outputs of above function are correct in tester
    std::cout << "Non zero elements are:" << std::endl;
    for (int i=0;i<matrix.row_start[matrix.no_rows];i++)
    {
        std::cout << matrix.matrix_entries[i] << " ";
    }
    std::cout << std::endl;
    std::cout << "Column numbers are:" << std::endl;
    for (int i=0;i<matrix.row_start[matrix.no_rows];i++)
    {
        std::cout << matrix.column_no[i] << " ";
    }
    std::cout << std::endl;
    std::cout << "Row starts are:" << std::endl;
    for (int i=0; i<matrix.no_rows+1;i++)
    {
        std::cout << matrix.row_start[i] << " ";
    }
    std::cout << std::endl;
}

void DeallocateCsrMatrix(csr_matrix& matrix)
{
    //Deallocate storage
    delete[] matrix.matrix_entries;
    delete[] matrix.column_no;
    delete[] matrix.row_start;
    matrix.no_rows=0; //for completeness
}

//Function to read matrix in csr format from file
csr_matrix ReadMatrixFile(std::string filename)
{
    csr_matrix matrix;
    std::ifstream readFile; //define input stream
    readFile.open(filename); //open file
    assert(readFile.is_open()); //check open
    std::string line; //define string to read lines into
    std::getline(readFile,line); //first line describes symmetric
    std::getline(readFile,line); //second line is 0 or 1 (integer to read in)
    matrix.symmetric=atoi(line.c_str()); //set symmetric equal to value
    std::getline(readFile,line); //next line says Number Rows
    std::getline(readFile,line); //get number of rows
    matrix.no_rows=atoi(line.c_str()); //set no_rows equal to that value
    std::getline(readFile,line); //next line says Number Nonzeroes
    std::getline(readFile,line); //get number of non-zero elements
    int num_NonZero; //not a variable within the struct, create variable
    num_NonZero=atoi(line.c_str()); //assign value
    std::getline(readFile,line); //ignore line announcing row_start
    matrix.row_start=new int[matrix.no_rows+1];
    for (int i=0;i<=matrix.no_rows;i++)
    {
        std::getline(readFile,line); //get element
        matrix.row_start[i]=atoi(line.c_str()); //assign to row_start
    }
    std::getline(readFile,line); //ignore line announcing column_no
    matrix.column_no=new int[num_NonZero];
    for (int i=0;i<num_NonZero;i++)
    {
        std::getline(readFile,line); //get element
        matrix.column_no[i]=atoi(line.c_str()); //assign to column_no
    }

    std::getline(readFile,line); //ignore line announcing matrix_entries
    matrix.matrix_entries=new double[num_NonZero];
    for (int i=0;i<num_NonZero;i++)
    {
        std::getline(readFile,line); //get element
        matrix.matrix_entries[i]=atof(line.c_str()); //assign to matrix_entries
    }
    readFile.close(); //close the file
    return matrix;
}

//Function to read in vector from a .dat file (piazza said could separate)
double* ReadVectorFile(std::string filename)
{
    double* pVector;
    int vector_length;
    std::ifstream readFile; //define input stream
    readFile.open(filename); //open file
    assert(readFile.is_open()); //check open
    std::string line; //define string to read lines into
    std::getline(readFile,line); //first line is Vector Length
    std::getline(readFile,line); //this is the length of the vector
    vector_length=atoi(line.c_str()); //assign length
    pVector=new double[vector_length]; //can now assign storage as length
    std::getline(readFile,line); //this line says Vector entries
    for (int i=0;i<vector_length;i++)
    {
        std::getline(readFile,line); //get entry value
        pVector[i]=atof(line.c_str()); //assign value to vector
    }
    readFile.close(); //close the file
    return pVector;
}
