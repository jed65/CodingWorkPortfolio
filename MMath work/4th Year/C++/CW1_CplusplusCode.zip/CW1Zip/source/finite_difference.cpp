#include <iostream>
#include <cmath>
#include <cassert>
#include "csr_matrix.hpp"

//The function to set up A for our problem and find f vector
csr_matrix SetUpFiniteDifference(int n, double* pFVector,
                                 double (*pFunction)(double x,double y))
{
  //First set up the matrix A
  csr_matrix A; //declare object which we'll be outputting later
  A.symmetric=true; //will set this up in format of a symmetric matrix (easier)
  A.no_rows=pow(n-1,2); //number of rows is (n-1)^2
  assert(n>1); //check that the input is valid (n greater or equal to 2)
  A.row_start=new int[A.no_rows+1]; //number of elements in row_start
  int number_non_zero=(n-2)*(3*n-2)+1; //length of matrix_entries/column_no
  A.matrix_entries=new double[number_non_zero];
  A.column_no=new int[number_non_zero];
  double h=1.0/(double)n; //distance between neighbouring points in mesh
  double diagonal_entry=4.0/pow(h,2.0)+1; //diagonal entry value
  double off_diagonal_entry=-1.0/pow(h,2.0); //off-diagonal entry value

  //Following section of code forms the 3 vector components of A
  A.row_start[0]=0; //first row starts from zero
  for (int k=0;k<A.no_rows;k++) //each k is a row of upper portion of A
  {
      if (k>=0 && k<=(pow(n-1,2)-(n-1)-1))
      {
          if ((k+1)%(n-1)==0) //if this true we only have 2 elements in row
          {
              A.row_start[k+1]=A.row_start[k]+2; //this row is 2 elements later
          }
          else //we have 3 elements per row in this case
          {
              A.row_start[k+1]=A.row_start[k]+3; //these rows 3 elements later
          }
          for (int j=A.row_start[k];j<A.row_start[k+1];j++)
          {
              if (j==A.row_start[k]) //start of row
              {
                  A.matrix_entries[j]=diagonal_entry; //diagonal here
                  A.column_no[j]=k;
              }
              else if (j==A.row_start[k+1]-1)
              {
                  A.matrix_entries[j]=off_diagonal_entry;
                  A.column_no[j]=k+n-1; //n-1 columns later
              }
              else //this only possible if third element
              {
                  A.matrix_entries[j]=off_diagonal_entry;
                  A.column_no[j]=k+1; //next to diagonal
              }
          }
      }
      //Next deal with rows guaranteed to have two elements (neighbouring)
      else if (k>=(pow(n-1,2)-(n-1)) && k<(pow(n-1,2)-1)) //2 elements per row
      {
          A.row_start[k+1]=A.row_start[k]+2; //new rows start 2 elements later
          int j=A.row_start[k]; //this is so we can make changes to other vecs
          A.matrix_entries[j]=diagonal_entry;
          A.column_no[j]=k;
          A.matrix_entries[j+1]=off_diagonal_entry;
          A.column_no[j+1]=k+1; //next to diagonal, guaranteed to be here
      }
      //Finally deal with the last element
      else //we are on the final row in this case, k=(n-1)^2-1
      {
          A.row_start[k+1]=A.row_start[k]+1; //final element
          A.matrix_entries[number_non_zero-1]=diagonal_entry;
          A.column_no[number_non_zero-1]=k;
      }
  }
  //Now need to form the f vector
  int counter=0;
  double x,y; //will be sent to function
  for (int i=1;i<n;i++)
  {
      x=i*h; //fix the x value
      for (int j=1;j<n;j++)
      {
          y=j*h; //go up columns for this x value
          pFVector[counter]=(*pFunction)(x,y); //evaluate/assign to pointer
          counter++; //add one here so keep elements can be assigned
      }
  }

  return A;
}
