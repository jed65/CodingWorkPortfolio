#include <iostream>
#include <cmath>
#include "csr_matrix.hpp"
//This function finds vector 2-norm
double ComputeVectorNorm(double* pVector,int n) //pass vector and it's length
{
    double twoNorm=0.0;
    for (int i=0;i<n;i++)
    {
        twoNorm+=pow(pVector[i],2.0); //add square of each element in p_vec
    }
    twoNorm=sqrt(twoNorm); //take square root to get norm, which is positive
    return twoNorm; //pass back the output
}

//This function finds vector dot product
double ComputeVectorDot(double* pVector1, double* pVector2, int n)
{
    double dotProduct=0.0;
    for (int i=0; i<n; i++)
    {
        dotProduct+=pVector1[i]*pVector2[i]; //add appropriate product
    }
    return dotProduct;
}

//Function combines two vectors in linear sum (multiplier is for 2nd vector)
void CombineLinearVecSum(double* pX,double* pVector1, double* pVector2,
                         double multiplier,int n)
{
    //Here, the combination is assigned to an existing vector (save storage)
    for (int i=0;i<n;i++)
    {
        pX[i]=pVector1[i]+multiplier*pVector2[i]; //form the combination
    }
}

//Function below implements given algorithm to solve Ax=b
double* SolveByKrylov(csr_matrix A, double* pProduct, double tol)
{
    int n=A.no_rows; //retrieve n from A
    double* pX;
    pX=new double[n]; //this is x that we aim to approximate
    double* p_r;
    p_r=new double[n]; //this is the residual vector
    double* p_rho;
    p_rho=new double[n]; //this is the conjugate gradient
    for (int i=0;i<n;i++)
    {
        pX[i]=0.0; //set initial guess to zero vector
        p_r[i]=pProduct[i]; //first residual with x zero vector is b (pProduct)
        p_rho[i]=p_r[i]; //first conjugate gradient is equal to residual
    }
    double residual_two_norm=ComputeVectorNorm(p_r,n); //compute 2 norm
    int counter=0; //tells us which iteration we're on later
    double alpha,beta; //these are used within the algorithm
    double* p_A_rho_product;
    p_A_rho_product=new double[n]; //this is Ap_k in algorithm
    double residual_k_dot,rho_A_rho_dot,residual_kplus_dot; //dot products
    while (residual_two_norm-tol>0.0) //keep going until two norm less than tol
    {
        std::cout << "Iteration:" << counter << std::endl; //output history
        std::cout << "Residual two norm:" << residual_two_norm << std::endl;
        //Start with step 1 of algorithm
        residual_k_dot=ComputeVectorDot(p_r,p_r,n); //find dot product rT*r
        p_A_rho_product=MultiplyAx(A,p_rho); //use function from Q1 here
        rho_A_rho_dot=ComputeVectorDot(p_rho,p_A_rho_product,n); // pT*Ap
        alpha=residual_k_dot/rho_A_rho_dot;
        //Step 2
        CombineLinearVecSum(pX,pX,p_rho,alpha,n); //Update x with formula
        //Step 3
        CombineLinearVecSum(p_r,p_r,p_A_rho_product,(-1.0)*alpha,n); //Update r
        //Step 4
        residual_kplus_dot=ComputeVectorDot(p_r,p_r,n); //Dot product w/ updated
        beta=residual_kplus_dot/residual_k_dot; //Calculate beta
        //Step 5
        CombineLinearVecSum(p_rho,p_r,p_rho,beta,n); //Update conjugate gradient
        residual_two_norm=ComputeVectorNorm(p_r,n); //Update two-norm with new r
        counter++; //Add one to iteration counter
    }
    std::cout << "Final iteration:" << counter << std::endl; //output history
    std::cout << "Residual two norm:" << residual_two_norm << std::endl;
    delete[] p_r; //deallocate storage for pointers not returned
    delete[] p_rho;
    delete[] p_A_rho_product;
    return pX; //return the approximate solution to the system
}


//This is the function for part 4a, copy/pasted above and modified
double* SolveByKrylovPreconditioned(csr_matrix A, double* pProduct, double tol)
{
    int n=A.no_rows; //retrieve n from A

    //This section of code performs the pre-conditioning
    //Make copy so code easy-to-follow, and values within A not changed
    csr_matrix inverseP_A; //declare
    inverseP_A.no_rows=n;
    inverseP_A.symmetric=A.symmetric;
    double multiplier=1.0/A.matrix_entries[0]; //multiplier for pre-conditioning
    inverseP_A.row_start=new int[n+1];
    for (int i=0;i<n+1;i++)
    {
        inverseP_A.row_start[i]=A.row_start[i]; //positions are unchanged
    }
    inverseP_A.column_no=new int[inverseP_A.row_start[n]];
    inverseP_A.matrix_entries=new double[inverseP_A.row_start[n]];
    //P^(-1) is diagonal matrix, value on diagonal constant(equal to multiplier)
    //The product is SPD when A has constant diagonal value (which in case of
    //3b is true), below makes appropriate change to entries.
    for (int i=0;i<inverseP_A.row_start[n];i++)
    {
        inverseP_A.column_no[i]=A.column_no[i]; //positions are unchanged
        inverseP_A.matrix_entries[i]=multiplier*A.matrix_entries[i]; //change
    }
    //Now we have the pre-conditioned matrix in csr format, also pre-condition b
    double* p_inversePb; //also need to change b in new system
    p_inversePb=new double[n]; //b has n number of elements (must do to be valid)
    for (int i=0;i<n;i++)
    {
        p_inversePb[i]=multiplier*pProduct[i]; //do preconditioning
    }
    //Got P^(-1)*A/P^(-1)*b, now repeat algorithm to find approximation to x
    //Most of code below is duplicated from 2a, modified to use objects above

    double* pX;
    pX=new double[n]; //this is x that we aim to approximate
    double* p_r;
    p_r=new double[n]; //this is the residual vector
    double* p_rho;
    p_rho=new double[n]; //this is the conjugate gradient
    for (int i=0;i<n;i++)
    {
        pX[i]=0.0; //set initial guess to zero vector
        p_r[i]=p_inversePb[i]; //first residual with x zero vector is P^(-1)*b
        p_rho[i]=p_r[i]; //first conjugate gradient is equal to residual
    }
    double residual_two_norm=ComputeVectorNorm(p_r,n); //compute 2 norm
    int counter=0; //tells us which iteration we're on later
    double alpha,beta; //these are used within the algorithm
    double* p_A_rho_product;
    p_A_rho_product=new double[n]; //this is Ap_k in algorithm
    double residual_k_dot,rho_A_rho_dot,residual_kplus_dot; //dot products
    while (residual_two_norm-tol>0.0) //keep going until two norm less than tol
    {
        std::cout << "Iteration:" << counter << std::endl; //output history
        std::cout << "Residual two norm:" << residual_two_norm << std::endl;
        //Start with step 1 of algorithm
        residual_k_dot=ComputeVectorDot(p_r,p_r,n); //find dot product rT*r
        p_A_rho_product=MultiplyAx(inverseP_A,p_rho); //use function from Q1
        rho_A_rho_dot=ComputeVectorDot(p_rho,p_A_rho_product,n); // pT*Ap
        alpha=residual_k_dot/rho_A_rho_dot;
        //Step 2
        CombineLinearVecSum(pX,pX,p_rho,alpha,n); //Update x with formula given
        //Step 3
        CombineLinearVecSum(p_r,p_r,p_A_rho_product,(-1.0)*alpha,n); //Update r
        //Step 4
        residual_kplus_dot=ComputeVectorDot(p_r,p_r,n); //Dot product w/ update
        beta=residual_kplus_dot/residual_k_dot; //Calculate beta
        //Step 5
        CombineLinearVecSum(p_rho,p_r,p_rho,beta,n); //Update conjugate gradient
        residual_two_norm=ComputeVectorNorm(p_r,n); //Update two-norm with new r
        counter++; //Add one to iteration counter
    }
    std::cout << "Final iteration:" << counter << std::endl; //output history
    std::cout << "Residual two norm:" << residual_two_norm << std::endl;
    delete[] p_r; //deallocate storage for pointers not returned
    delete[] p_rho;
    delete[] p_A_rho_product;

    //Also need to deallocate objects involved in pre-conditioning
    delete[] p_inversePb;
    DeallocateCsrMatrix(inverseP_A);


    return pX; //return the approximate solution to the system
}
