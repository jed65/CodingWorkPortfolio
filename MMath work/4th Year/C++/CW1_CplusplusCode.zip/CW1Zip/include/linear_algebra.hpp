double* SolveByKrylov(csr_matrix A, double* pProduct, double tol);
double* SolveByKrylovPreconditioned(csr_matrix A, double* pProduct, double tol);
double ComputeVectorNorm(double* p_vec,int n);
double ComputeVectorDot(double* vec1, double* vec2, int n);
void CombineLinearVecSum(double* p_x,double* vec1, double* vec2, double multi,
                         int n);
