struct csr_matrix //define in header file as told to by hint
{
    int no_rows; //define number of rows in n x n matrix
    double* matrix_entries; //no restriction for entries to be integers
    int* column_no; //the two vectors tells us where entries are, must be int
    int* row_start;
    bool symmetric; //tells us whether or not the matrix is symmetric
};
csr_matrix SetUpRegularMatrix(int noRows, double** pA);
csr_matrix SetUpSymmetricMatrix(int noRows,double** pA);
double* MultiplyAx(csr_matrix A,double* pX);
void DeallocateCsrMatrix(csr_matrix& matrix);
void PrintVectors(csr_matrix matrix);
csr_matrix ReadMatrixFile(std::string filename);
double* ReadVectorFile(std::string filename);
