csr_matrix SetUpFiniteDifference(int n, double* pFVector,
                                 double (*pFunction)(double x,double y));
