#include <iostream>
#include <cmath>
#include "csr_matrix.hpp"
#include "linear_algebra.hpp"
#include "finite_difference.hpp"

double ComputeF(double x, double y);

int main(int argc, char* argv[])
{
    int n=16; //first n value we're interested in
    double maximum;
    for (int i=1; i<=5; i++)
    {
        double* p_fValues;
        int no_of_u=pow(n-1,2); //number of u values for this n
        p_fValues=new double[no_of_u];
        csr_matrix A=SetUpFiniteDifference(n,p_fValues,ComputeF); //call
        double* p_U=SolveByKrylov(A,p_fValues,1e-10); //use function from q2
        for (int j=0;j<no_of_u;j++) //now find maximum
        {
            if (j==0)
            {
                maximum=p_U[j]; //initialise maximum to first value
            }
            else
            {
                if (p_U[j]-maximum>=0.0) //if U[j] bigger than current max, update
                {
                    maximum=p_U[j];
                }
                //no need for else here, won't update if above doesn't hold
            }
        }
        std::cout << "Maximum for n=" << n << " is:" << maximum << std::endl;
        //Now free up storage to avoid excessive use of memory
        DeallocateCsrMatrix(A);
        delete[] p_fValues;
        delete[] p_U;
        n=2*n;
    }
    return 0;
}
//Expect that the maximum is near to 1, where x=y=0.5. Indeed this is true for
//n=16 but strangely here as a greater n is used the maximum of the
//approximation increases further from the maximum at 1. Convergence is studied
//with respect to grid function norms, what this calculates is the infinity norm
//so it's odd (perhaps not right) that the above quantities don't approach 1.
//Nevertheless, we only studied the grid function 2-norm last year, and the code
//seems correct to me.

//Function defining f(x,y)
double ComputeF(double x, double y)
{
    return (2.0*pow(M_PI,2.0)+1.0)*sin(M_PI*x)*sin(M_PI*y); //compute f(x,y)
}
