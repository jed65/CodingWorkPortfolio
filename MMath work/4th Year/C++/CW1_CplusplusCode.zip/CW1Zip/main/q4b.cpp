#include <iostream>
#include <cmath>
#include "csr_matrix.hpp"
#include "linear_algebra.hpp"
#include "finite_difference.hpp"

//Code is copied from q3b.cpp with one change, uses SolveByKrylovPreconditioned
//which applies pre-conditioning by taking P as diagonal of A then solves
//P^(-1)*A*x=P^(-1)*b for x.
double ComputeF(double x, double y);

int main(int argc, char* argv[])
{
    int n=16; //first n value we're interested in
    double maximum;
    for (int i=1; i<=5; i++)
    {
        double* p_fValues;
        int no_of_u=pow(n-1,2); //number of u values for this n
        p_fValues=new double[no_of_u];
        csr_matrix A=SetUpFiniteDifference(n,p_fValues,ComputeF); //call
        double* p_U=SolveByKrylovPreconditioned(A,p_fValues,1e-10); //use func
        for (int j=0;j<no_of_u;j++) //now find maximum
        {
            if (j==0)
            {
                maximum=p_U[j]; //initialise maximum to first value
            }
            else
            {
                if (p_U[j]-maximum>=0.0) //if U[j] bigger than max, update
                {
                    maximum=p_U[j];
                }
                //no need for else here, won't update if above doesn't hold
            }
        }
        std::cout << "Maximum for n=" << n << " is:" << maximum << std::endl;
        //Now free up storage to avoid excessive use of memory
        DeallocateCsrMatrix(A);
        delete[] p_fValues;
        delete[] p_U;
        n=2*n;
    }
    return 0;
}

//As expected convergence occurs at a quicker rate. For example, with n=256 it
//takes 900 iterations to reach an error below 1e-10, whereas without
//pre-conditioning it took over 1000 iterations.


//Function defining f(x,y)
double ComputeF(double x, double y)
{
    return (2.0*pow(M_PI,2.0)+1.0)*sin(M_PI*x)*sin(M_PI*y); //compute f(x,y)
}
