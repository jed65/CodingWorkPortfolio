#include <iostream>
#include <cmath>
#include <string>
#include "csr_matrix.hpp"
#include "linear_algebra.hpp"

int main(int argc,char* argv[])
{
    std::string filename1="matrix2.dat";
    std::string filename2="vector2.dat";
    csr_matrix A=ReadMatrixFile(filename1); //read in A in csr format
    double* p_x=ReadVectorFile(filename2); //read in x as pointer
    double* p_b=MultiplyAx(A,p_x); //calculate b=Ax as asked by question
    double* p_xhat=SolveByKrylov(A,p_b,1e-10); //use function with tol
    double* p_xerror;
    p_xerror=new double[A.no_rows]; //allocate storage
    CombineLinearVecSum(p_xerror,p_x,p_xhat,-1.0,A.no_rows); //form x-xhat
    double error_norm=ComputeVectorNorm(p_xerror,A.no_rows); //find error
    std::cout.precision(10); //want to see greater precision
    std::cout << "Two-norm error of Krylov subspace approximation:" <<
    error_norm << std::endl; //output as requested in question
    //Rest of code deallocates above
    DeallocateCsrMatrix(A);
    delete[] p_x;
    delete[] p_b;
    delete[] p_xhat;
    delete[] p_xerror;
    return 0;
}
