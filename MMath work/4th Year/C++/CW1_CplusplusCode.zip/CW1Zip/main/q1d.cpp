#include <iostream>
#include <cmath>
#include "csr_matrix.hpp"

int main(int argc, char* argv[])
{
    int n=4;
    double** p_A;
    p_A=new double*[n]; //allocate storage
    for (int i=0; i<n;i++)
    {
        p_A[i]=new double[n];
        for (int j=0; j<n;j++)
        {
            p_A[i][j]=0.0; //fill with zero elements to initialise
        }
    }
    //Use the matrix given in the example, fill non-zero elements
    p_A[0][0]=8.0; p_A[0][3]=2.0;
    p_A[1][1]=3.0; p_A[1][3]=1.0;
    p_A[2][2]=4.0;
    p_A[3][0]=2.0; p_A[3][1]=1.0; p_A[3][3]=7.0;
    double* p_x;
    p_x=new double[n];
    p_x[0]=6.0;p_x[1]=8.0;p_x[2]=2.0;p_x[3]=5.0;
    csr_matrix A_csr=SetUpSymmetricMatrix(n,p_A); //get csr format of A
    double* p_sym_Ax=MultiplyAx(A_csr,p_x); //get product
    std::cout << "Matrix-vector product in symmetric case is:" << std::endl;
    for (int i=0;i<n;i++)
    {
        std::cout << p_sym_Ax[i] << " "; //output product
    }
    std::cout << std::endl;
    csr_matrix A_csr2=SetUpRegularMatrix(n,p_A); //set up in non-symmetric case
    double* p_non_sym_Ax=MultiplyAx(A_csr2,p_x); //get product from same function
    std::cout << "Matrix-vector product in non-symmetric case is:" << std::endl;
    for (int i=0;i<n;i++)
    {
        std::cout << p_non_sym_Ax[i] << " "; //output product
    }
    std::cout << std::endl;
    DeallocateCsrMatrix(A_csr);
    DeallocateCsrMatrix(A_csr2);
    //delete storage associated with above terms
    for (int i=0;i<n;i++)
    {
        delete[] p_A[i];
    }
    delete[] p_A;
    delete[] p_x;
    delete[] p_sym_Ax;
    delete[] p_non_sym_Ax;
    return 0;
}
