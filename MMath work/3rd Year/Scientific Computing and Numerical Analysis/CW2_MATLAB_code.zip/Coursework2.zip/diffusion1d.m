function [eT,uT] = diffusion1d(theta,kappa,T,Nx,Nt,p,mark,col)
% diffusion1d.m: This function takes inputs of theta (parameter for the
% theta method), kappa (diffusion constant), the maximum time T, the number
% of sub-intervals in the x-direction Nx, the number of sub-intervals in
% the time-direction plus indicator values p and mark (plot curve if p=1
% and the mark value allows a marker style to be chosen). It then applies
% the theta method on the time-derivative and second order centred
% difference on the space derivative to approximate u, giving the vector of
% u approximations and the grid function 2-norm error at the final time
% t=T. A plot is produced and error displayed if the indicator p is set to
% value 1.


%Define required terms
h=2/Nx; %first few lines define step lengths in x and t
dt=T/Nt;
r=kappa*dt/h^2; %required for the matrix
x=linspace(-1,1,Nx+1); %vector of x values for any fixed time
u=cos(pi.*x); %initialise the u vector using the condition for t=0
u=u'; %transpose the u vector
%Create the matrices to be used at each time-step
an=1-2*(1-theta)*r; %next few lines define non-zero terms in tridiagonal matrix
bn=(1-theta)*r;
cn=(1-theta)*r;
An=diag(an*ones(1,Nx+1))+diag(bn*ones(1,Nx),1)+diag(cn*ones(1,Nx),-1);
An(1,2)=2*bn; %these two lines swap these elements for values given by the Neumann conditions
An(Nx+1,Nx)=2*cn;

anplus=1+2*theta*r;
bnplus=-theta*r;
cnplus=-theta*r;
Anplus=diag(anplus*ones(1,Nx+1))+diag(bnplus*ones(1,Nx),1)+diag(cnplus*ones(1,Nx),-1);
Anplus(1,2)=2*bnplus;
Anplus(Nx+1,Nx)=2*cnplus;
%Apply the method
for i=1:Nt %this for loop solves the matrix equation for the approximations at each step
    b=An*u;
    u=Anplus\b;
end
uT=u;
%Calculate the 2-norm error of approximation and the true solution at t=T
uTrueT=exp(-kappa*(pi^2)*T).*cos(pi.*x);
uTrueT=uTrueT';
e=uTrueT-uT;
esquare=e.^2;
normsquare=esquare.*h;
eT=sqrt(sum(normsquare));
%Plot the approximation with the true solution when t=T if p=1
if p==1 
    m={'+','o','*','x','s','d'};
    colour={'b','r','g','c','m','y'};
    X=linspace(-1,1,1000);
    U=exp(-kappa*(pi^2)*T).*cos(pi.*X);
    plot(X,U,'-k');
    hold on
    for j=1:Nx+1
        plot(x(j),uT(j),'Color',colour{col},'Marker',m{mark});
    end
    xlabel('x');
    ylabel('u');
    title('1D Diffusion Equation Approx.');
    hold off
    disp(['The 2-norm error for theta=',num2str(theta),' is ',num2str(eT)]);
else
end
    


    


