function [uRD] = reaction_diffusion1d(theta,kappa,T,Nx,Nt,p,mark)
%reaction_diffusion1d.m: This function takes inputs of theta (parameter for
%the theta method), kappa (diffusion constant), maximum time T, number of
%space sub-intervals Nx, number of time-steps Nt, and indicator values p
%and mark which alter the format of the plot. It then applies the theta
%method in time, the second-order centred difference method in space and
%the forward-Euler method for the reaction term to produce a vector of
%approximations at time T uRD. A plot of the approximations with the
%initial condition is produced if p is set to 1.


%Define required terms
h=2/Nx; %first few lines define step lengths in x and t
dt=T/Nt;
r=kappa*dt/h^2; %required for the matrix
x=linspace(-1,1,Nx+1); %vector of x values for any fixed time
u=cos(pi.*x); %initialise the u vector using the condition for t=0
u=u'; %transpose the u vector
%Create the matrices to be used at each time-step
an=1-2*(1-theta)*r; %next few lines define non-zero terms in tridiagonal matrix
bn=(1-theta)*r;
cn=(1-theta)*r;
An=diag(an*ones(1,Nx+1))+diag(bn*ones(1,Nx),1)+diag(cn*ones(1,Nx),-1);
An(1,2)=2*bn; %these two lines swap these elements for values given by the Neumann conditions
An(Nx+1,Nx)=2*cn;

anplus=1+2*theta*r;
bnplus=-theta*r;
cnplus=-theta*r;
Anplus=diag(anplus*ones(1,Nx+1))+diag(bnplus*ones(1,Nx),1)+diag(cnplus*ones(1,Nx),-1);
Anplus(1,2)=2*bnplus;
Anplus(Nx+1,Nx)=2*cnplus;
for i=1:Nt %this for loop solves the matrix equation for the approximations at each step
    b=An*u+dt*(u-u.^3);
    u=Anplus\b;
end
uRD=u;

%Plot the approximation with the true solution when t=T if p=1
if p==1 
    m={'+','o','*','x','s','d'};
    X=linspace(-1,1,1000);
    UZero=cos(pi.*X);
    plot(X,UZero,'-k');
    hold on
    for j=1:Nx+1
        plot(x(j),uRD(j),'b','Marker',m{mark})
    end
    xlabel('x');
    ylabel('u');
    title('1D Reaction-Diffusion Equation Approx.');
    hold off
else
end


