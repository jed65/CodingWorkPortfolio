function [u,e] = diffusion2d(kappa,T,Nx,Ny,Nt,p)
%diffusion2d.m: This function takes inputs of kappa (from the problem), the
%final time T and the number of space/time-steps Nx (in x), Ny (in y) and
%Nt (in time) then finds an approximate solution to the 2D diffusion
%equation using second-order centred difference approximations in space and
%the forward Euler method in time. If the indicator value p is set to 1 the
%approximation is plotted as a surface and the 2-norm error is displayed.
%The matrix of approximations u can be obtained as an output along with the
%grid function 2-norm error e.


%Define required terms
hx=2/Nx; %first few lines define the space and time steps
hy=2/Ny;
dt=T/Nt;
x=linspace(-1,1,Nx+1); %the next few lines define our mesh 
y=linspace(-1,1,Ny+1);
[xgrid,ygrid]=meshgrid(x,y);
u=cos(pi.*xgrid).*cos(pi.*ygrid); %initialise the mesh points
uplusdt=zeros(Ny+1,Nx+1);
a=1-(2*kappa*dt)/hx^2-(2*kappa*dt)/hy^2; %next few lines define multipliers used in the method
b=kappa*dt/hx^2;
c=kappa*dt/hy^2;
%Implement the method
for i=1:Nt %runs for specified number of time-steps
    for j=1:Nx+1 %each j fixes a value of x
        for k=1:Ny+1 %this fixes a value of y
            if j==1 %need to apply boundary symmetry conditions in the following two cases for j, and ignore the corners of the mesh for now
                if k==1||k==Ny+1 %ignore these cases in the for loop
                    uplusdt(k,1)=1; 
                else
                    uplusdt(k,1)=a*u(k,1)+2*b*u(k,2)+c*(u(k+1,1)+u(k-1,1));
                end
                
            elseif j==Nx+1
                if k==1||k==Ny+1 %ignore these cases in the for loop
                    uplusdt(k,Nx+1)=1;
                else
                    uplusdt(k,Nx+1)=a*u(k,Nx+1)+2*b*u(k,Nx)+c*(u(k+1,Nx+1)+u(k-1,Nx+1));
                end
            else
                if k==1
                    uplusdt(1,j)=a*u(1,j)+b*(u(1,j+1)+u(1,j-1))+2*c*u(2,j);
                elseif k==Ny+1
                    uplusdt(Ny+1,j)=a*u(Ny+1,j)+b*(u(Ny+1,j+1)+u(Ny+1,j-1))+2*c*u(Ny,j);
                else
                    uplusdt(k,j)=a*u(k,j)+b*(u(k,j+1)+u(k,j-1))+c*(u(k+1,j)+u(k-1,j));
                end
            end
        end
    end
    uplusdt(1,1)=a*u(1,1)+2*b*u(1,2)+2*c*u(2,1);%values are different in the corners of the mesh
    uplusdt(Ny+1,1)=uplusdt(1,1); %the other corners are equal to the first since we have symmetry in x=0 and y=0
    uplusdt(1,Nx+1)=uplusdt(1,1);
    uplusdt(Ny+1,Nx+1)=uplusdt(1,1);
    u=uplusdt; %update u for the next iteration
end
%Find the grid-function 2-norm error
uTrue=exp(-2*kappa*pi^2*T).*cos(pi.*xgrid).*cos(pi.*ygrid);
error=uTrue-u;
errorpower2=error.^2;
VolumeError=hx.*hy.*errorpower2;
e=sqrt(sum(VolumeError,'all'));
%Plot the approximation at t=T if p==1
if p==1 
    surf(x,y,u); 
    xlabel('x');
    ylabel('y');
    zlabel('u');
    title('2D Diffusion Equation Approximation');
    disp(['The 2-norm error at t=',num2str(T),' is ',num2str(e)]);
else
end


