function [Nt,dt] = FindMaxDt(theta,kappa,Nx,NtZero)

Nt=NtZero; %sets Nt to the initial guess NtZero
NtStable=0; %initialise values for while loop
NtUnstable=0;
while NtStable==0 %the for loop gives an interval to bisect
    [u]=reaction_diffusion1d(theta,kappa,20,Nx,Nt,0,1); %obtain vector of approximations
    Unstable=sum(isnan(u)); %if unstable, has NaN values 
    if Unstable>0 
        NtUnstable=Nt; %there are unstable elements so set the lower bound of interval to this Nt
    else
        NtStable=Nt; %the approximations are stable for this Nt, so set upper bound to this Nt
    end
    Nt=2*Nt; %run through loop again with larger Nt (higher chance of this being stable)
end

BisectionWidth=NtStable-NtUnstable; %this is the width of the interval that the lowest stable Nt sits in
while BisectionWidth>1 %guarantees we will get close to this lowest value of Nt we require
    NtTest=0.5*(NtUnstable+NtStable); %at each iteration, the midpoint of the bisection interval is tested for its stability
    [u]=reaction_diffusion1d(theta,kappa,20,Nx,NtTest,0,1);
    Unstable2=sum(isnan(u)); %same process as the first while loop, but this time we have an interval which is made smaller with each loop
    if Unstable2>0
        NtUnstable=NtTest;
    else 
        NtStable=NtTest;
    end
    BisectionWidth=NtStable-NtUnstable; %test the while loop criterion
end

Nt=NtStable; %this is the lowest stable value of Nt that has been found
dt=20/Nt; %this is the value of dt for this stable value of Nt

