function [u,v]=reaction_diffusion2d(epsilon,T,alpha,beta,u0,v0,Nx,Ny,Nt,jx,ky,p)
%reaction_diffusion2d.m: This function takes inputs in the form of
%coefficients from the problem (epsilon, alpha, beta), the final time T,
%the initial conditions u0 and v0 as matrices, and the number of space/time
%steps Nx, Ny and Nt as well as the coordinates of a spatial mesh point of
%interest jx and ky and an indicator value p. It then forms an
%approximation to u and v in the reaction-diffusion equation, plotting each
%as a surface if p=1 and plotting the time evolution of the spatial mesh
%point if p=2. 

%Define required terms
hx=80/Nx; %first few lines define the space and time steps
hy=80/Ny;
dt=T/Nt;
x=linspace(-40,40,Nx+1); %define x and y for the plots later
y=linspace(-40,40,Ny+1);
uplusdt=zeros(Ny+1,Nx+1); %these lines initialise the un+1 and vn+1 matrices
vplusdt=zeros(Ny+1,Nx+1);
a=1-(2*dt)/hx^2-(2*dt)/hy^2+dt/epsilon; %next few lines define multipliers used in the method
b=dt/hx^2;
c=dt/hy^2;
d=dt/epsilon;
u=u0; %set u and v equal to their inputted initial conditions u0 and v0
v=v0;

Time=zeros(Nt+1,0); %initialise the vectors which are used when the user picks a spatial mesh point
Time(1)=0;
Ujx_ky=zeros(Nt+1,0);
Ujx_ky(1)=u(ky,jx);
Vjx_ky=zeros(Nt+1,0);
Vjx_ky(1)=v(ky,jx);


%Implement the method
for i=1:Nt %runs for specified number of time-steps
    for j=1:Nx+1 %each j fixes a value of x
        for k=1:Ny+1 %this fixes a value of y
            if j==1 %need to apply boundary symmetry conditions in the following cases for j
                if k==1
                    uplusdt(k,1)=a*u(1,1)+2*b*u(1,2)+2*c*u(2,1)-(d/3)*u(1,1)^3-d*v(1,1); 
                elseif k==Ny+1
                    uplusdt(k,1)=a*u(k,1)+2*b*u(k,2)+2*c*u(Ny,1)-(d/3)*u(k,1)^3-d*v(k,1);
                else
                    uplusdt(k,1)=a*u(k,1)+2*b*u(k,2)+c*(u(k+1,1)+u(k-1,1))-(d/3)*u(k,1)^3-d*v(k,1);
                end
                
            elseif j==Nx+1
                if k==1 %first two conditions are the other corners
                    uplusdt(k,Nx+1)=a*u(k,Nx+1)+2*b*u(k,Nx)+2*c*u(2,Nx+1)-(d/3)*u(k,Nx+1)^3-d*v(k,Nx+1);
                elseif k==Ny+1
                    uplusdt(k,Nx+1)=a*u(k,Nx+1)+2*b*u(k,Nx)+2*c*u(Ny,Nx+1)-(d/3)*u(k,Nx+1)^3-d*v(k,Nx+1);
                else
                    uplusdt(k,Nx+1)=a*u(k,Nx+1)+2*b*u(k,Nx)+c*(u(k+1,Nx+1)+u(k-1,Nx+1))-(d/3)*u(k,Nx+1)^3-d*v(k,Nx+1);
                end
            else
                if k==1 %apply boundary symmetry conditions in following 2 cases for k
                    uplusdt(1,j)=a*u(1,j)+b*(u(1,j+1)+u(1,j-1))+2*c*u(2,j)-(d/3)*u(1,j)^3-d*v(1,j);
                elseif k==Ny+1
                    uplusdt(Ny+1,j)=a*u(Ny+1,j)+b*(u(Ny+1,j+1)+u(Ny+1,j-1))+2*c*u(Ny,j)-(d/3)*u(Ny+1,j)^3-d*v(Ny+1,j);
                else
                    uplusdt(k,j)=a*u(k,j)+b*(u(k,j+1)+u(k,j-1))+c*(u(k+1,j)+u(k-1,j))-(d/3)*u(k,j)^3-d*v(k,j);
                end
            end
            vplusdt(k,j)=v(k,j)+epsilon*dt*(u(k,j)+beta-alpha*v(k,j)); %v needs to be updated too using forward-Euler method for time
        end
    end
    u=uplusdt; %update u for the next iteration
    v=vplusdt; %update v for the next iteration
    
    Time(i+1)=Time(i)+dt; %assign appropriate elements for the spatial mesh point requested by the user
    Ujx_ky(i+1)=u(ky,jx);
    Vjx_ky(i+1)=v(ky,jx);
end

%Produce plots
if p==1 %Plot the approximations for u/v at t=T if p==1
    subplot(2,1,1);
    surf(x,y,u); 
    xlabel('x');
    ylabel('y');
    zlabel('u');
    title('Approximation for u at final time T');
    
    subplot(2,1,2);
    surf(x,y,v); 
    xlabel('x');
    ylabel('y');
    zlabel('v');
    title('Approximation for v at final time T');
elseif p==2 %Plot the time evolution of user chosen mesh point if p==2
    subplot(2,1,1);
    hold on
    for i=1:Nt+1
        plot(Time(i),Ujx_ky(i),'b*');
    end
    hold off
    xlabel('t');
    ylabel('u');
    title('Time evolution of u');
    
    subplot(2,1,2);
    hold on
    for i=1:Nt+1
        plot(Time(i),Vjx_ky(i),'go');
    end
    hold off
    xlabel('t');
    ylabel('v');
    title('Time evolution of v')
else     
end
    
