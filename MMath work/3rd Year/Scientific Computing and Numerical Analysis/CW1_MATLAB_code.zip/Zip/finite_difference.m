function [y,e] = finite_difference(eps,N,p)
%finite_difference: Takes input in number of sub-intervals on (0,pi) and a
%value for epsilon which is in the differential question and calculates
%vector of approximations y found through finite difference, along with the
%grid function 2-norm e and plots the approximation against the true
%solution if the indicator value p is equal to 1.

%Define terms we need to use
x=linspace(0,pi,N+1);
h=pi/N;
a=1-2/(h^2); %these few lines define the multipliers present in each equation, to go into the matrix
b=1/(h^2)+1/(2*h*eps);
c=1/(h^2)-1/(2*h*eps);
%Define matrix and B vector in Ay=B
A=diag(a*ones(1,N-1))+diag(b*ones(1,N-2),1)+diag(c*ones(1,N-2),-1); %creates tridiagonal matrix
B=zeros(N-1,1);
B(1)=cos(x(2))-c; %this is different due to the initial condition
for i=2:N-1
    B(i)=cos(x(i+1)); 
end
yInBetween=A\B;%gives y1 to yN-1
yInBetween=yInBetween'; %makes this vector horizontal so that we can concatenate
y=[1,yInBetween,0]; %defines the y vector of approximations
%Calculate the error e
expplus=-1+sqrt(1-4*eps^2); %the next few lines define the true solution
expminus=-1-sqrt(1-4*eps^2);
expmulti=sqrt(1-4*eps^2)*(pi/eps);
ytrue=[exp((0.5).*expplus.*(x./eps))-exp(expmulti).*exp((0.5).*expminus.*(x./eps))]./(1-exp(expmulti))+eps.*sin(x); %calculate true solution at the discretisation points
error=ytrue-y; %the next few lines calculate the grid-function 2-norm
errorsquared=error.^2;
normsquared=errorsquared.*h;
e=sqrt(sum(normsquared));
%Plot the approximation with the exact solution when p=1
if p==1
    X=linspace(0,pi,1000); 
    Y=[exp((0.5).*expplus.*(X./eps))-exp(expmulti).*exp((0.5).*expminus.*(X./eps))]./(1-exp(expmulti))+eps.*sin(X);
    plot(X,Y,'-k');
    hold on
    for j=1:N+1
        plot(x(j),y(j),'*b');
    end
    xlabel('x');
    ylabel('y');
    title('Finite difference approximation');
    hold off
else 
end
    



