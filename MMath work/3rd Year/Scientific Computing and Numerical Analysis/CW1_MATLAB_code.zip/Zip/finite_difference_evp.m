function [eigApprox,eigError,y,e] = finite_difference_evp(epsilon,N,n,p)
%finite_difference_evp.m: Takes inputs of epsilon (inherited from the
%problem), N (number of sub-intervals), n (the particular eigenvalue the
%user is interested in) and p (indicator value: plots graph if p=1), and
%computes an approximation to the specified numbered eigenvalue along with
%its error, the approximations of y with this eigenvalue and the
%grid-function 2-norm for the y approximations e, where the approximations
%are found through second-order centred-difference methods for y'' and y'.

x=linspace(0,pi,N+1); %define the required terms
h=pi/N;
a=1-2/(h^2); %next few lines define the non-zero elements of the tridiagonal matrix
b=1/(h^2)+1/(2*h*epsilon);
c=1/(h^2)-1/(2*h*epsilon);
A=diag(a*ones(1,N-1))+diag(b*ones(1,N-2),1)+diag(c*ones(1,N-2),-1); %matrix which we're interested in for this problem
eigvalues=eig(A);
eigvalues=sort(eigvalues);
eigApprox=eigvalues(N-n);%assigns the approximate to the eigenvalue to the correct element of the vector of eigenvalues
eigApprox=real(eigApprox);
eigTrue=1-n^2-1/(4*epsilon^2); %defines the true eigenvalue
eigError=abs(eigTrue-eigApprox); 
[V,D]=eig(A); %calls eig function to give us the eigenvectors and eigenvalues 
[~,ind]=sort(diag(D)); %this is required as eig does not sort the eigenvalues/vectors for us 
Vs=V(:,ind); %puts the eigenvectors into the appropriate order
yBetween=Vs(:,N-n); %gives the appropriate eigenvector for the input n
y=[0,yBetween',0]; %these are the estimates (not scaled)
yTrue=exp((-0.5.*x)./epsilon).*sin(n.*x); %these are the true values
y=real(y); %corrects if eig function gives imaginary numbers
a=max(abs(y)); 
y=y./a; %rescales
if min(y)==-1 %fixes any inverted plots
    y=(-1).*y;
else
end
b=max(abs(yTrue));
yTrue=yTrue./b; %rescales
error=yTrue-y; %next few lines calculate the grid function 2-norm
errorsquared=error.^2;
normsquared=errorsquared.*h;
e=sqrt(sum(normsquared));
% Plot the graph if p=1
if p==1
    X=linspace(0,pi,1000);
    Y=exp((-0.5.*X)./epsilon).*sin(n.*X);
    
    c=max(abs(Y)); %rescale 
    Y=Y./c;
    
    plot(X,Y,'-k');
    y=real(y);
    hold on
    for j=1:N+1
        plot(x(j),y(j),'*b');
    end
    xlabel('x');
    ylabel('y');
    title('Finite Difference EVP Approximation');
    hold off
else
end


