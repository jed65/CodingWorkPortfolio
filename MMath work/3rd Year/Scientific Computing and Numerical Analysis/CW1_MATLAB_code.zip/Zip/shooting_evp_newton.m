function [e,eigError,ylamb] = shooting_evp_newton(epsilon,N,n,lambdaZero,p)
%shooting_evp_newton.m: Takes inputs of epsilon (from the problem), number
%of sub-intervals N, the eigenvalue number n which you want the error for,
%an initial guess lambdaZero and an indicator value p which displays the
%iteration number and approximation/plots a graph if set to 1. The outputs
%are the grid-function 2-norm error associated with the eigenfunction
%approximation, the error in the selected eigenvalue approximation and the
%vector of approximations to the eigenfunction.

x=linspace(0,pi,N+1); %define required terms and initialise variables
h=pi/N;
lambda=lambdaZero; 
NewtonDifference=1; 
j=0;
while NewtonDifference>1e-5 %condition ensures the loop only ends when Newton method converges
dlambda=lambda+10*sqrt(eps); %the forward Euler method is applied for lambda and a small perturbation
ylamb=zeros(N+1,1);
vlamb=zeros(N+1,1);
ydlamb=zeros(N+1,1);
vdlamb=zeros(N+1,1);
ydlamb(1)=0;
vdlamb(1)=1;
ylamb(1)=0;
vlamb(1)=1;
for i=1:N %apply the method to obtain approximations
    ylamb(i+1)=ylamb(i)+h*vlamb(i);
    vlamb(i+1)=vlamb(i)+h*((lambda-1)*ylamb(i)-vlamb(i)/epsilon);
    ydlamb(i+1)=ydlamb(i)+h*vdlamb(i);
    vdlamb(i+1)=vdlamb(i)+h*((dlambda-1)*ydlamb(i)-vdlamb(i)/epsilon);
end
yPi=ylamb(N+1);
j=j+1; %iteration number
ydPi=ydlamb(N+1);
oldlamb=lambda;
dylambda=(ydPi-yPi)/(10*sqrt(eps));
lambda=lambda-yPi/dylambda; %update lambda using Newton method
NewtonDifference=abs(lambda-oldlamb); %check the condition of the loop
if p==1 %only display these if p=1
    disp(['Iteration:',num2str(j)]);
    disp(['Approximate Eigenvalue:',num2str(lambda,10)])
else
end
end
%Calculate the errors 
eigTrue=1-n^2-1/(4*epsilon^2);
eigError=abs(eigTrue-lambda);
yTrue=exp((-0.5.*x)./epsilon).*sin(4.*x);
a=max(abs(yTrue));  %rescaling
yTrue=yTrue./a;
b=max(abs(ylamb));
ylamb=ylamb./b;
FinalError=yTrue-ylamb'; %next few lines calculate the grid function 2-norm
errorsquared=FinalError.^2;
normsquared=errorsquared.*h;
e=sqrt(sum(normsquared));
%Plot graph if p=1
if p==1
    X=linspace(0,pi,1000);
    Y=exp((-0.5.*X)./epsilon).*sin(4.*X);
   
    c=max(abs(Y)); %rescale
    Y=Y./c;
    
    plot(X,Y,'-k');
    hold on 
    for k=1:N+1
        plot(x(k),ylamb(k),'xr');
    end
    xlabel('x');
    ylabel('y');
    title('Shooting Method Approximation');
    hold off
end

        
    

