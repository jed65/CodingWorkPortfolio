function [y,e] = shooting_forward_euler(eps,N,c1,c2,p)
%shooting_forward_euler.m: Takes input in number of sub-intervals on (0,pi)
%and a value epsilon required for the BVP, along with two approximations to
%the value of y' at 0 c1 and c2 and produces the vector of estimates y
%along with the grid function 2-norm e. A plot is produced with the
%approximations from y'(0)=c1,c2, the superposition y and the exact
%solution when p is set to 1.

% Define the required terms
x=linspace(0,pi,N+1);
h=pi/N;
% Use c1 to obtain approximation y1
y1=zeros(N+1,1);
v1=zeros(N+1,1);
y1(1)=1;
v1(1)=c1;
for i=1:N %this for loop applies forward euler method on the system
    y1(i+1)=y1(i)+h*v1(i);
    v1(i+1)=v1(i)+h*(cos(x(i))-y1(i)-v1(i)/eps);
end
% Use c2 to obtain approximation y2
y2=zeros(N+1,1);
v2=zeros(N+1,1);
y2(1)=1;
v2(1)=c2;
for i=1:N
    y2(i+1)=y2(i)+h*v2(i);
    v2(i+1)=v2(i)+h*(cos(x(i))-y2(i)-v2(i)/eps);
end
% Obtain alpha1 and alpha2 using the above and use these to obtain y
alpha1=y2(N+1)/(y2(N+1)-y1(N+1));
alpha2=-y1(N+1)/(y2(N+1)-y1(N+1));
y=alpha1.*y1+alpha2.*y2;
% Calculate the error e
expplus=-1+sqrt(1-4*eps^2); %the next few lines define the true solution
expminus=-1-sqrt(1-4*eps^2);
expmulti=sqrt(1-4*eps^2)*(pi/eps);
ytrue=[exp((0.5).*expplus.*(x./eps))-exp(expmulti).*exp((0.5).*expminus.*(x./eps))]./(1-exp(expmulti))+eps.*sin(x); %calculate true solution at the discretisation points
error=ytrue-y'; %the next few lines calculate the grid-function 2-norm
errorsquared=error.^2;
normsquared=errorsquared.*h;
e=sqrt(sum(normsquared));
% Plot the approximations if p=1
if p==1
    X=linspace(0,pi,1000); 
    Y=[exp((0.5).*expplus.*(X./eps))-exp(expmulti).*exp((0.5).*expminus.*(X./eps))]./(1-exp(expmulti))+eps.*sin(X);
    plot(X,Y,'-k');
    hold on
    for j=1:N+1
        plot(x(j),y1(j),'or');
        plot(x(j),y2(j),'*m');
        plot(x(j),y(j),'db');
    end
    xlabel('x');
    ylabel('y');
    title('Forward-Euler Shooting Method');
    legend({'Exact Solution','c1','c2','Approximation'},'Location','northeast','NumColumns',1);
    hold off
    disp(['The values of alpha1 and alpha2 respectively are ',num2str(alpha1),' and ',num2str(alpha2)]);
else
end



